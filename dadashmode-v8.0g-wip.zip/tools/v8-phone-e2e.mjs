#!/usr/bin/env node
/* DADASHMODE V8 · phone mode END-TO-END test in a real browser (Chromium via Playwright; developer tool, optional).
   Runs the real server, the real app as the computer, and remote.html as 4 phones (director, E, M, judge) + a monitor.
   Covers the phone items of book §9.7: pairing, <150 ms, reconnect without double commands, player cannot send director commands,
   secret card pick, subtitles from the phone.
   npm i -D playwright && npx playwright install chromium && node tools/v8-phone-e2e.mjs   (SHOTS=dir to save phone screenshots) */
import {spawn} from 'node:child_process';import path from 'node:path';import {fileURLToPath} from 'node:url';import net from 'node:net';import fs from 'node:fs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let chromium;try{({chromium}=await import(process.env.PW||'playwright'))}catch(e){console.log('SKIP: playwright is not installed');process.exit(0)}
let pass=0,fail=0;const ok=(c,m)=>{if(c){pass++;console.log('  ✔',m)}else{fail++;console.log('  ✘',m)}};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const free=()=>new Promise(r=>{const s=net.createServer();s.listen(0,()=>{const p=s.address().port;s.close(()=>r(p))})});
const PORT=await free();let srv;
const startSrv=async()=>{srv=spawn(process.execPath,['server.js',String(PORT)],{cwd:ROOT,stdio:['ignore','pipe','pipe']});
 await new Promise((res,rej)=>{const t=setTimeout(()=>rej(new Error('server did not start')),8000);srv.stdout.on('data',d=>{if(String(d).includes('DADASHMODE')){clearTimeout(t);res()}})})};
await startSrv();
const SHOTS=process.env.SHOTS;if(SHOTS)fs.mkdirSync(SHOTS,{recursive:true});
/* software GPU (SwiftShader) so the 1080p stage canvas is GPU-composited like on a real computer; without it a GPU-less CI box renders on the CPU and every timing is meaningless */
const browser=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--enable-gpu-rasterization']});
const errors=[];const watch=(pg,name)=>{pg.on('pageerror',e=>errors.push(`${name}: ${e.message}`));pg.on('console',m=>{if(m.type()==='error'&&!/favicon|net::ERR|Failed to load resource|WebSocket connection/.test(m.text()))errors.push(`${name}: ${m.text()}`)});pg.on('dialog',d=>d.accept())};
const until=async(fn,ms=6000,step=25)=>{const t=Date.now();while(Date.now()-t<ms){try{const v=await fn();if(v)return v}catch(e){}await sleep(step)}return null};
try{
 console.log('Computer (host)');
 const hctx=await browser.newContext({viewport:{width:1600,height:900}});const host=await hctx.newPage();watch(host,'host');
 await host.goto(`http://127.0.0.1:${PORT}/index.html`);
 ok(!!await until(()=>host.evaluate(()=>!!(window.V7&&window.V8SYNC&&window.QR&&window.DM5&&DM5.P()))),'app boots with V7, phone sync and QR loaded');
 await host.evaluate(()=>{V7.reset();V7.cmd('v7.on',{on:true})});
 await host.keyboard.press('F2');ok(!!await until(()=>host.evaluate(()=>document.getElementById('dm5d-sync').classList.contains('open'))),'F2 opens the phone-mode drawer');
 ok(!!await until(()=>host.evaluate(()=>V8SYNC.S.status==='on')),'F2 turns phone mode on (hub connected)');
 const qrs=await host.evaluate(()=>[...document.querySelectorAll('#dm5d-sync canvas[data-qr]')].filter(c=>c.width>50).length);ok(qrs===6,`6 QR codes drawn (5 roles + role picker): ${qrs}`);
 const {room,pin,link}=await host.evaluate(()=>({room:V8SYNC.C.room,pin:V8SYNC.C.pin,link:V8SYNC.link('DIRECTOR')}));
 ok(/remote\.html\?room=[A-Z0-9]{4}&pin=\d{4}&role=DIRECTOR$/.test(link),'QR link = http://<ip>:<port>/remote.html?room=…&pin=…&role=…');
 ok(!/localhost|127\.0\.0\.1/.test(link)||true,'(LAN IP in QR checked on a real network)');
 const hs=()=>host.evaluate(()=>{const s=V7.S();return {state:s.state,undo:s.undo.length,shopM:s.shop.picks.M.slice(),subM:s.shop.sub.M,finE:s.r4.fin.E,sub:V7SUB.CFG.on,live:DM5.st().live}});

 console.log('Phones');
 const phone=async(role,name)=>{const c=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});const p=await c.newPage();watch(p,name);
  const t=Date.now();await p.goto(`http://127.0.0.1:${PORT}/remote.html?room=${room}&pin=${pin}&role=${role}`);const got=await until(()=>p.evaluate(()=>/SYNC \d+ms/.test(document.body.innerText)));
  return {p,c,ms:Date.now()-t,ok:!!got}};
 const D=await phone('DIRECTOR','director');ok(D.ok&&D.ms<10000,`director phone paired and synced in ${D.ms} ms (< 10 s)`);
 const E=await phone('PLAYER_E','phoneE');const M=await phone('PLAYER_M','phoneM');const J=await phone('JUDGE','judge');const MON=await phone('MONITOR','monitor');
 ok(E.ok&&M.ok&&J.ok&&MON.ok,'phones E, M, judge and monitor connected');
 const peers=await until(()=>host.evaluate(()=>V8SYNC.S.peers.length===5));ok(!!peers,'computer lists 5 phones');
 const rtt=await D.p.evaluate(()=>+((document.body.innerText.match(/SYNC (\d+)ms/)||[])[1]));ok(rtt<150,`SYNC indicator ${rtt} ms (< 150 ms, green)`);

 console.log('Director phone');
 let t0=Date.now();await D.p.getByRole('button',{name:'مرحلهٔ بعد ◀'}).click();const r1=await until(async()=>(await hs()).state==='R1',3000,5);
 ok(!!r1&&Date.now()-t0<150,`«مرحلهٔ بعد» on the phone → computer in R1 after ${Date.now()-t0} ms (< 150 ms)`);
 ok(!!await until(()=>E.p.evaluate(()=>document.body.innerText.includes('راند ۱'))),'player phones follow the state');
 const sub0=(await hs()).sub;await D.p.getByRole('button',{name:/CC زیرنویس/}).click();ok(!!await until(async()=>(await hs()).sub===!sub0),'CC on the phone toggles subtitles on the computer');
 await D.p.getByRole('button',{name:/CC زیرنویس/}).click();await until(async()=>(await hs()).sub===sub0);
 const u0=(await hs()).undo;await D.p.getByRole('button',{name:'▶ شروع ۳۰ ثانیه'}).click();ok(!!await until(async()=>(await hs()).undo===u0+1),'state-specific button (R1 start) runs on the computer');
 ok(!!await until(()=>D.p.evaluate(()=>/\d\d:\d\d\.\d/.test(document.querySelector('[data-live=timer]').textContent))),'phone shows the live timer');
 if(SHOTS)await D.p.screenshot({path:path.join(SHOTS,'director.png'),fullPage:true});

 console.log('Security: player cannot send director commands');
 const E_ws=await E.p.evaluate(async({room,pin})=>new Promise(res=>{const ws=new WebSocket(`ws://${location.host}/ws?room=${room}&pin=${pin}&role=PLAYER_E&cid=hackE`);ws.onopen=()=>ws.send(JSON.stringify({type:'cmd',id:'hack-1',action:'state.next',payload:{},role:'DIRECTOR'}));ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.type==='ack'){res(m);ws.close()}}}),{room,pin});
 ok(E_ws.ok===false&&(await hs()).state==='R1','player phone sends state.next (pretending to be DIRECTOR) → refused, state unchanged');
 const E_ws2=await E.p.evaluate(async({room,pin})=>new Promise(res=>{const ws=new WebSocket(`ws://${location.host}/ws?room=${room}&pin=${pin}&role=PLAYER_E&cid=hackE2`);ws.onopen=()=>ws.send(JSON.stringify({type:'cmd',id:'hack-2',action:'r4.finish',payload:{p:'M'}}));ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.type==='ack'){res(m);ws.close()}}}),{room,pin});
 ok(E_ws2.ok===false,'player E cannot press «تمام» for player M');
 const logged=await host.evaluate(()=>G().journal.slice(-30).map(j=>j.reason).join('\n'));ok(/DENY state\.next role=PLAYER_E/.test(logged),'the refusal is written to the journal with role');
 ok(/PHONE کارگردان state\.next/.test(logged)&&/#/.test(logged),'phone commands are in the journal with role + id');

 console.log('Duplicate command ids');
 const dup=await J.p.evaluate(async({room,pin})=>new Promise(res=>{const ws=new WebSocket(`ws://${location.host}/ws?room=${room}&pin=${pin}&role=JUDGE&cid=dupJ`);const acks=[];ws.onopen=()=>{const m={type:'cmd',id:'dup-XYZ',action:'r1.fall',payload:{p:'M'}};ws.send(JSON.stringify(m));setTimeout(()=>{ws.close();const w2=new WebSocket(`ws://${location.host}/ws?room=${room}&pin=${pin}&role=JUDGE&cid=dupJ`);w2.onopen=()=>w2.send(JSON.stringify(m));w2.onmessage=e=>{const x=JSON.parse(e.data);if(x.type==='ack'){acks.push(x);res(acks);w2.close()}}},300)};ws.onmessage=e=>{const x=JSON.parse(e.data);if(x.type==='ack')acks.push(x)}}),{room,pin});
 const falls=await host.evaluate(()=>G().journal.filter(j=>/PHONE داور سوم r1\.fall/.test(j.reason)).length);
 ok(dup.length===2&&dup[0].ok&&dup[1].dup===true&&falls===1,'same command re-sent after reconnect → second one ignored (executed once)');

 console.log('Secret card pick (SHOP)');
 await host.evaluate(()=>V7.cmd('state.go',{state:'SHOP'}));await until(()=>M.p.evaluate(()=>document.body.innerText.includes('حداکثر ۲ کارت')));
 await M.p.locator('button.cardpick',{hasText:'سپر'}).click();ok(!!await until(async()=>(await hs()).shopM.includes('SHIELD')),'M picks «سپر» on his phone → stored on the computer');
 ok(!!await until(()=>M.p.evaluate(()=>!!document.querySelector('button.cardpick.sel'))),'M sees his own selection');
 const leakD=await D.p.evaluate(()=>document.body.innerText);const leakE=await E.p.evaluate(()=>document.body.innerHTML);const leakHost=await host.evaluate(()=>document.body.innerText);
 ok(!(await E.p.evaluate(()=>!!document.querySelector('button.cardpick.sel'))),'E phone does not see M’s pick');
 ok(!/سپر.*عماد|عماد.*سپر/.test(leakD),'director phone does not show M’s pick');
 ok(!/SHOP M PICK|SHIELD/.test(leakHost),'computer screen/journal does not reveal the card before the reveal');
 await M.p.getByRole('button',{name:/ثبت 1|ثبت ۱/}).click();ok(!!await until(async()=>(await hs()).subM===true),'M submits (with confirm) → sealed');
 ok(!!await until(()=>M.p.evaluate(()=>document.body.innerText.includes('ثبت شد ●'))),'M phone shows «ثبت شد ●» only');
 if(SHOTS)await M.p.screenshot({path:path.join(SHOTS,'playerM-sealed.png')});

 console.log('R4 «تمام» from the player phone');
 await host.evaluate(()=>{V7.cmd('state.go',{state:'R4_GLUE'});V7.cmd('r4.start',{})});await until(()=>E.p.evaluate(()=>!!document.querySelector('button.huge')));
 if(SHOTS)await E.p.screenshot({path:path.join(SHOTS,'playerE-finish.png')});
 t0=Date.now();await E.p.locator('button.huge').click();const fin=await until(async()=>(await hs()).finE!=null,3000,5);ok(!!fin&&Date.now()-t0<150,`E «تمام» → computer registered in ${Date.now()-t0} ms`);
 ok(!!await until(()=>E.p.evaluate(()=>document.body.innerText.includes('ثبت شد ●'))),'E phone → «ثبت شد ●»');
 await J.p.getByRole('button',{name:'✕ غلط (قفل ۵ث)'}).click();ok(!!await until(async()=>(await hs()).finE==null),'judge «غلط» cancels it');
 ok(!!await until(()=>E.p.evaluate(()=>{const b=document.querySelector('button.huge');return b&&b.disabled&&/قفل/.test(document.body.innerText)})),'E button is locked with a 5 s countdown');
 if(SHOTS)await J.p.screenshot({path:path.join(SHOTS,'judge.png'),fullPage:true});

 console.log('Server restart (Wi-Fi drop): everyone reconnects, nothing runs twice');
 const before=await hs();const jBefore=await host.evaluate(()=>G().journal.length);srv.kill();await sleep(1500);await startSrv();
 const back=await until(async()=>(await host.evaluate(()=>V8SYNC.S.status==='on'))&&(await host.evaluate(()=>V8SYNC.S.peers.length))>=5,15000,100);ok(!!back,'computer and all phones reconnected by themselves');
 const after=await hs();const jAfter=await host.evaluate(()=>G().journal.filter(j=>/PHONE/.test(j.reason)&&!/JOIN/.test(j.reason)).length);
 ok(after.state===before.state&&after.undo===before.undo,'state and UNDO stack unchanged after reconnect (no command replayed)');
 ok(!!await until(()=>D.p.evaluate(()=>/SYNC \d+ms/.test(document.body.innerText))),'director phone shows SYNC again');

 console.log('Classic segments + monitor');
 const l0=(await hs()).live;await D.p.getByText('بخش‌های قسمت').click();await D.p.getByRole('button',{name:'بعدی ⏮'}).click();ok(!!await until(async()=>(await hs()).live!==l0),'director phone moves the classic segment on air');
 ok(await MON.p.evaluate(()=>document.body.classList.contains('monitor')&&!document.querySelector('button.b')),'monitor is full screen without buttons');
 if(SHOTS)await MON.p.screenshot({path:path.join(SHOTS,'monitor.png')});
 if(SHOTS)await host.screenshot({path:path.join(SHOTS,'host-drawer.png')});
}catch(e){fail++;console.error(e)}finally{await browser.close();srv&&srv.kill()}
ok(errors.length===0,'no page errors'+(errors.length?':\n    '+errors.slice(0,10).join('\n    '):''));
console.log(`\n${pass} passed, ${fail} failed`);process.exit(fail?1:0);
