/* node tools/v8-games-selftest.mjs · data-driven engine for new games (4 modes) + .ml integration */
import fs from 'node:fs';import vm from 'node:vm';import path from 'node:path';import {fileURLToPath} from 'node:url';
const dir=path.join(path.dirname(fileURLToPath(import.meta.url)),'..');
const ctx=vm.createContext({console,Math,Date,JSON,Object,Array,String,Number,Set,Map,RegExp,Error,Infinity});ctx.globalThis=ctx;ctx.window=ctx;const mem={};ctx.localStorage={getItem:k=>mem[k]??null,setItem:(k,v)=>{mem[k]=String(v)}};ctx.navigator={};
const load=f=>vm.runInContext(fs.readFileSync(path.join(dir,f),'utf8'),ctx,{filename:f});
load('js/util.js');load('js/data.js');load('js/v7-rules.js');load('js/v8-games.js');load('js/v8-ml.js');
const G=ctx.V8G,M=ctx.V8ML;let pass=0,fail=0;const eq=(n,g,e)=>{const a=JSON.stringify(g),b=JSON.stringify(e);if(a===b){pass++;console.log('✔',n)}else{fail++;console.log('✘',n,'\n   got',a,'\n   exp',b)}};
const sc=(e,r)=>G.score(G.norm(e),r).awards;
// first
const F={mode:'first',limit:60,reward:15,fallback:5,tie:{band:0.5,award:10}};
eq('first: only E finished → E +15',sc(F,{finish:{E:40}}),{E:15});
eq('first: both, M faster by 3s → M +15',sc(F,{finish:{E:43,M:40}}),{M:15});
eq('first: 0.4s apart = tie → both +10 (book §8.5 R4 style)',sc(F,{finish:{E:40.4,M:40}}),{E:10,M:10});
eq('first: after limit does not count',sc(F,{finish:{E:61,M:59}}),{M:15});
eq('first: nobody, more progress → +5',sc(F,{progress:{E:3,M:5}}),{M:5});
eq('first: nobody, equal progress → nothing',sc(F,{progress:{E:4,M:4}}),{});
eq('first R1-style: tie band 0.5 award 5',sc({mode:'first',reward:10,fallback:5,tie:{band:0.5,award:5}},{finish:{E:12.1,M:12.5}}),{E:5,M:5});
// points
const Pt={mode:'points',reward:10,events:[{id:'hit',label:'گل',value:1,max:3},{id:'bonus',label:'ضربهٔ طلایی',value:2}],tie:{award:5}};
eq('points: winner by sum',sc(Pt,{events:{E:['hit','hit'],M:['hit']}}),{E:10});
eq('points: max caps per event (4 hits count as 3)',G.score(G.norm(Pt),{events:{E:['hit','hit','hit','hit'],M:['bonus']}}).sums,{E:3,M:2});
eq('points: equal sum → tie award',sc(Pt,{events:{E:['bonus'],M:['hit','hit']}}),{E:5,M:5});
eq('points: 0-0 → nothing',sc(Pt,{events:{E:[],M:[]}}),{});
eq('points: award=sum → each gets own sum',sc({mode:'points',award:'sum',events:[{id:'l1',value:5},{id:'l3',value:20}]},{events:{E:['l1','l3'],M:['l1']}}),{E:25,M:5});
// metric
const Mt={mode:'metric',reward:10,metric:{label:'ثانیه',better:'lower',scale:'diff',factor:1,floor:3,cap:20},tie:{band:1,award:5}};
eq('metric diff: 31.4 vs 46.8 → +15 (sandwich numbers)',sc(Mt,{metric:{E:46.8,M:31.4}}),{M:15});
eq('metric diff: 2.2 apart → floor 3',sc(Mt,{metric:{E:30,M:32.2}}),{E:3});
eq('metric diff: 0.6 apart → tie both +5',sc(Mt,{metric:{E:30.6,M:30}}),{E:5,M:5});
eq('metric diff: 40 apart → cap 20',sc(Mt,{metric:{E:10,M:50}}),{E:20});
eq('metric higher fixed',sc({mode:'metric',reward:10,metric:{better:'higher'}},{metric:{E:3.2,M:2.9}}),{E:10});
eq('metric only one result',sc({mode:'metric',reward:10},{metric:{E:null,M:7}}),{M:10});
// judge + common
eq('judge pick',sc({mode:'judge',reward:8},{pick:'M'}),{M:8});
eq('judge tie',sc({mode:'judge',reward:8,tie:{award:4}},{pick:'tie'}),{E:4,M:4});
eq('penalties hit bank directly',sc({mode:'judge',reward:10,penalties:[{id:'foul',value:3}]},{pick:'E',penaltiesHit:{E:['foul'],M:['foul','foul']}}),{E:7,M:-6});
eq('loser penalty',sc({mode:'judge',reward:10,loser:-5},{pick:'E'}),{E:10,M:-5});
eq('maxAward clamp',sc({mode:'points',award:'sum',maxAward:12,events:[{id:'a',value:10}]},{events:{E:['a','a'],M:[]}}),{E:12});
eq('segment defaults: reward + limit from segment',[G.norm({mode:'first'},{duration:45,reward:12}).limit,G.norm({mode:'first'},{duration:45,reward:12}).reward],[45,12]);
// check
eq('check: bad mode',G.check({mode:'x'}).errors.length,1);eq('check: points without events',G.check({mode:'points'}).errors.length,1);eq('check: duplicate ids',G.check({mode:'points',events:[{id:'a'}],penalties:[{id:'a'}]}).errors.length,1);
// .ml integration
const base={format:'dadashmode-ml/1',name:'فصل ۲',players:[{name:'الیاس'},{name:'عماد'}],speakers:[{id:'host'}],segments:[{type:'play',game:'generic',title:'پرتاب کفش',duration:45,rules:['۳ پرتاب'],engine:Mt}]};
const v=M.validate(base);eq('ml: valid new game with engine',[v.errors.length,v.stats.autoGames],[0,1]);
const bad=JSON.parse(JSON.stringify(base));bad.segments[0].engine={mode:'points'};eq('ml: engine errors surface in report',M.validate(bad).errors.some(e=>e.includes('events')),true);
const ep=M.toEpisode(base);eq('ml → episode keeps engine',ep.segments[0].engine.mode,'metric');
eq('episode → ml keeps engine',M.fromEpisode(ep).segments[0].engine.metric.cap,20);
const pr=M.buildPrompt({});eq('prompt documents all 4 modes',['"first"','"points"','"metric"','"judge"'].every(x=>pr.includes(x)),true);
console.log(`\n${pass} passed, ${fail} failed`);process.exit(fail?1:0);
