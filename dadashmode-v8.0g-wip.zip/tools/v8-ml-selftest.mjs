/* node tools/v8-ml-selftest.mjs · .ml pipeline: prompt, parse (fence/comments/trailing commas), validate, build, round-trip with episode 1 */
import fs from 'node:fs';import vm from 'node:vm';import path from 'node:path';import {fileURLToPath} from 'node:url';
const dir=path.join(path.dirname(fileURLToPath(import.meta.url)),'..');
const ctx=vm.createContext({console,Math,Date,JSON,Object,Array,String,Number,Set,Map,RegExp,Error,Infinity});ctx.globalThis=ctx;const mem={};ctx.localStorage={getItem:k=>mem[k]??null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]}};ctx.navigator={};ctx.window=ctx;
const load=f=>vm.runInContext(fs.readFileSync(path.join(dir,f),'utf8'),ctx,{filename:f});
load('js/util.js');load('js/data.js');load('js/v7-rules.js');load('js/v8-games.js');load('js/v8-ml.js');
const M=ctx.V8ML,R=ctx.V7R;let pass=0,fail=0;
const ok=(name,c,info)=>{if(c){pass++;console.log('✔',name)}else{fail++;console.log('✘',name,info!==undefined?'\n   '+JSON.stringify(info).slice(0,400):'')}};
const reg=M.registry();
ok('registry sees segment types, games, emotions, 19 states',Object.keys(reg.types).length>=9&&Object.keys(reg.games).length>=9&&Object.keys(reg.emotions).length>=12&&reg.states.length===19,{t:Object.keys(reg.types).length,s:reg.states.length});
const ep1=JSON.parse(fs.readFileSync(path.join(dir,'episodes/ep1-time-bank.json'),'utf8'));
const ml=M.fromEpisode(ep1);
ok('export ep1 → .ml keeps 33 segments / 78 lines',ml.segments.length===33&&ml.segments.reduce((a,s)=>a+s.lines.length,0)===78);
ok('export carries book lists (16 targets, 10 riddles, 12 envelopes, 6 bites)',ml.lists.targets.length===16&&ml.lists.riddles.length===10&&ml.lists.envelopes.length===12&&ml.lists.bites.length===6);
ok('flow derived from segments = book order',JSON.stringify(ml.flow)===JSON.stringify(M.BOOK_FLOW),ml.flow);
const v=M.validate(ml);ok('ep1 .ml validates with 0 errors',v.errors.length===0,v.errors);
const back=M.toEpisode(JSON.parse(JSON.stringify(ml)));
ok('round-trip: same segment order + v7 states',JSON.stringify(back.segments.map(s=>[s.type,s.game,s.v7]))===JSON.stringify(ep1.segments.map(s=>[s.type,s.game,s.v7])));
ok('round-trip: dialogue text identical',JSON.stringify(back.segments.flatMap(s=>s.lines.map(l=>[l.speaker,l.emotion,l.text])))===JSON.stringify(ep1.segments.flatMap(s=>s.lines.map(l=>[l.speaker,l.emotion,l.text]))));
ok('round-trip: targets engine shape',back.v7bank.targets[14].name==='دستکش'&&back.v7bank.targets[14].callback===true&&back.v7bank.targets[14].accept.includes('دستکش بوکس'));
ok('round-trip: riddle answers 0..9',back.v7bank.riddles.map(r=>r.answer).join('')==='0123456789');
ok('built episode has v7book so migrate() will not overwrite it',back.v7book==='ml'&&back.format==='dadashmode-episode/3');
/* parse tolerance */
const claude='باشه، این هم فایل:\n```json\n{\n // comment\n "name":"تست",\n "players":[{"name":"a"},{"name":"b"},],\n "segments":[{"type":"title","title":"x"}],\n}\n```\nموفق باشی';
const p=M.parse(claude);ok('parse: code fence + comment + trailing commas',p.data&&p.data.name==='تست'&&p.data.players.length===2,p.errors);
ok('parse: YAML is reported, not crashed',M.parse('name: x\nplayers:\n - a').errors.length===1);
ok('parse: broken JSON reported',M.parse('{"a":').errors.length===1);
/* validation catches real mistakes */
const bad={name:'x',players:[{name:'a'}],speakers:[{id:'host'}],segments:[{type:'movie'},{type:'play',v7:'R9',lines:[{speaker:'nila',text:'سلام'}]}],lists:{riddles:[{answer:12,normal:''}]},flow:['R1','FOO'],rules:{r1:{limit:20,zzz:1}}};
const bv=M.validate(bad);const has=s=>bv.errors.some(e=>e.includes(s));
ok('validate: 1 player',has('دقیقاً ۲'));ok('validate: bad type',has('movie'));ok('validate: bad v7',has('R9'));ok('validate: unknown speaker',has('nila'));
ok('validate: riddle answer 12',has('رقم ۰ تا ۹'));ok('validate: unknown flow module',has('FOO'));ok('validate: unknown rule key is a warning',bv.warnings.some(w=>w.includes('zzz')));
/* new game + custom flow */
const s2=JSON.parse(JSON.stringify(ml));s2.name='فصل ۲ · قسمت ۱';s2.flow=['READY','R1','R3_SANDWICH','SHOP','VAULT','CASE','END'];
s2.segments.splice(2,0,{type:'play',game:'generic',title:'پرتاب کفش',rules:['هر نفر ۳ پرتاب'],duration:45,reward:10,scoring:'نزدیک‌ترین به سطل +10',lines:[{speaker:'host',emotion:'هیجان‌زده',text:'بازی جدید!'}]});
s2.rules={r1:{limit:40}};s2.intros={R1:['جمنای','راند یک فصل دو.']};s2.stateNames={R1:'برج لیوان ۲'};
const v2=M.validate(s2);ok('season-2 file with a new game validates',v2.errors.length===0&&v2.stats.newGames===1,v2.errors);
const e2=M.toEpisode(s2);ok('new game becomes generic play segment with scoring in notes',e2.segments[2].game==='generic'&&!e2.segments[2].v7&&e2.segments[2].notes.includes('نزدیک‌ترین'));
ok('Persian emotion name mapped to key',e2.segments[2].lines[0].emotion==='excited');
ok('rules override stored in v7cfg',e2.v7cfg.r1.limit===40);
/* overlay on the live engine objects */
ctx.V7={NEXT:{READY:'R1',R1:'R2',R2:'R3_SANDWICH',R3_SANDWICH:'TWIST_BANKOPEN',SHOP:'SHOP_REVEAL',SHOP_REVEAL:'RISK',RUN2:'CASE',END:'END',GLUE_CHALLENGE:'R4_GLUE'},INTRO:{R1:['جمنای','راند یک.']}};
M.overlay(e2);
ok('overlay: flow skips R2 (R1→R3_SANDWICH)',ctx.V7.NEXT.R1==='R3_SANDWICH');ok('overlay: SHOP_REVEAL→VAULT_ARMED',ctx.V7.NEXT.SHOP_REVEAL==='VAULT_ARMED');
ok('overlay: intro + state name',ctx.V7.INTRO.R1[1]==='راند یک فصل دو.'&&R.STATE_FA.R1==='برج لیوان ۲');
M.overlay(ep1);ok('overlay resets for an episode without .ml',ctx.V7.NEXT.R1==='R2'&&ctx.V7.INTRO.R1[1]==='راند یک.'&&R.STATE_FA.R1==='راند ۱ · برج لیوان');
/* prompt */
const pr=M.buildPrompt({withDialogues:true,example:ml});
ok('prompt lists every state, module, type and emotion',reg.states.every(s=>pr.includes(s))&&Object.keys(M.MODULES).every(m=>pr.includes(m))&&Object.keys(reg.emotions).every(e=>pr.includes(e)));
ok('prompt includes live rule config + format tag',pr.includes('"r3"')&&pr.includes(M.FORMAT));
fs.mkdirSync(path.join(dir,'episodes'),{recursive:true});fs.writeFileSync(path.join(dir,'episodes/ep1-time-bank.ml'),JSON.stringify(ml,null,1));fs.writeFileSync(path.join(dir,'episodes/claude-prompt-sample.txt'),pr);
console.log(`\n${pass} passed, ${fail} failed`);process.exit(fail?1:0);
