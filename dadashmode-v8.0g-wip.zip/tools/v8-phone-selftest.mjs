#!/usr/bin/env node
/* DADASHMODE V8 · phone mode hub self-test (book §9.2 / §9.7 «حالت گوشی»). Starts the real server on a free port and talks to it
   with Node's built-in WebSocket (Node ≥ 22) as computer (HOST) and phones. No browser, no npm packages.
   node tools/v8-phone-selftest.mjs                                                                                           */
import {spawn} from 'node:child_process';import path from 'node:path';import {fileURLToPath} from 'node:url';import net from 'node:net';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
if(typeof WebSocket==='undefined'){console.log('SKIP: this Node has no built-in WebSocket (needs Node 22+)');process.exit(0)}
let pass=0,fail=0;const ok=(c,m)=>{if(c){pass++;console.log('  ✔',m)}else{fail++;console.log('  ✘',m)}};
const free=()=>new Promise(r=>{const s=net.createServer();s.listen(0,()=>{const p=s.address().port;s.close(()=>r(p))})});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const PORT=await free();const srv=spawn(process.execPath,['server.js',String(PORT)],{cwd:ROOT,stdio:['ignore','pipe','pipe']});
await new Promise((res,rej)=>{let t=setTimeout(()=>rej(new Error('server did not start')),8000);srv.stdout.on('data',d=>{if(String(d).includes('DADASHMODE')){clearTimeout(t);res()}})});
const U=q=>`ws://127.0.0.1:${PORT}/ws?${new URLSearchParams(q)}`;
function client(q){const ws=new WebSocket(U(q));const box={ws,msgs:[],closed:null,open:false};
 ws.onopen=()=>{box.open=true};ws.onmessage=e=>{box.msgs.push(JSON.parse(e.data))};ws.onclose=e=>{box.closed=e.code};
 box.send=o=>ws.send(JSON.stringify(o));box.wait=async(f,ms=2000)=>{const t=Date.now();while(Date.now()-t<ms){const m=box.msgs.find(f);if(m)return m;if(box.closed!=null&&!f.closeOk)break;await sleep(10)}return null};
 box.waitClose=async(ms=2000)=>{const t=Date.now();while(Date.now()-t<ms){if(box.closed!=null)return box.closed;await sleep(10)}return null};return box}
try{
 console.log('HTTP');
 const cfg=await (await fetch(`http://127.0.0.1:${PORT}/api/config`)).json();ok(cfg.ws===true,'/api/config reports ws:true');
 const lan=await (await fetch(`http://127.0.0.1:${PORT}/api/lan`)).json();ok(Array.isArray(lan.ips)&&+lan.port===PORT,'/api/lan gives LAN IPs + port');
 const rem=await fetch(`http://127.0.0.1:${PORT}/remote.html?room=ABCD&pin=1234`);ok(rem.status===200&&(await rem.text()).includes('js/remote.js'),'remote.html is served (with query string)');
 const rjs=await fetch(`http://127.0.0.1:${PORT}/js/remote.js`);ok(rjs.status===200,'js/remote.js is served');

 console.log('Pairing + PIN');
 const early=client({room:'ROOM1',pin:'1234',role:'PLAYER_E',cid:'e0'});ok(await early.waitClose()===4001,'phone before the computer opened the room → rejected (no PIN yet)');
 const host=client({room:'ROOM1',pin:'1234',role:'HOST',token:'tok1'});ok(!!await host.wait(m=>m.type==='hello'&&m.role==='HOST'),'computer (HOST) opens room ROOM1 with PIN');
 const bad=client({room:'ROOM1',pin:'9999',role:'PLAYER_E',cid:'x'});ok(await bad.waitClose()===4001,'wrong PIN → closed 4001');
 const badRole=client({room:'ROOM1',pin:'1234',role:'HOST2',cid:'x2'});ok(await badRole.waitClose()===4002,'unknown role → closed 4002');
 const badRoom=client({room:'a!',pin:'1234',role:'PLAYER_E'});ok(await badRoom.waitClose()===4000,'malformed room → closed 4000');
 const t0=Date.now();const E=client({room:'room1',pin:'1234',role:'PLAYER_E',cid:'cidE'});const hE=await E.wait(m=>m.type==='hello');
 ok(hE&&hE.role==='PLAYER_E'&&hE.host===true,`phone E joins (room name case-insensitive) in ${Date.now()-t0} ms`);
 const M=client({room:'ROOM1',pin:'1234',role:'PLAYER_M',cid:'cidM'});await M.wait(m=>m.type==='hello');
 const Dp=client({room:'ROOM1',pin:'1234',role:'DIRECTOR',cid:'cidD'});await Dp.wait(m=>m.type==='hello');
 const peers=await host.wait(m=>m.type==='peers'&&m.list.length===3);ok(!!peers&&peers.list.map(p=>p.role).sort().join()==='DIRECTOR,PLAYER_E,PLAYER_M','computer sees 3 phones with their roles');
 const thief=client({room:'ROOM1',pin:'1234',role:'HOST',token:'other'});ok(await thief.waitClose()===4009,'a second computer with another token cannot take over the room (4009)');

 console.log('Roles are stamped by the server');
 E.send({type:'cmd',id:'e-1',action:'state.next',payload:{},role:'DIRECTOR'});const c1=await host.wait(m=>m.type==='cmd'&&m.id==='e-1');
 ok(c1&&c1.role==='PLAYER_E'&&c1.cid==='cidE','phone E claims role DIRECTOR in the message → computer still receives role PLAYER_E');
 ok(c1&&typeof c1.rx==='number','server adds its receive time');
 host.send({type:'ack',cid:'cidE',id:'e-1',ok:false,err:'اجازه ندارید'});const a1=await E.wait(m=>m.type==='ack'&&m.id==='e-1');ok(a1&&a1.ok===false,'ack goes back only to the sender');
 await sleep(80);ok(!M.msgs.some(m=>m.type==='ack'),'other phones do not get that ack');

 console.log('Private snapshot parts');
 host.send({type:'state',seq:1,pub:{state:'SHOP',banks:{E:80,M:55}},priv:{PLAYER_E:{shop:{picks:['GLOVES']}},PLAYER_M:{shop:{picks:['MIRROR']}}}});
 const sE=await E.wait(m=>m.type==='state'),sM=await M.wait(m=>m.type==='state'),sD=await Dp.wait(m=>m.type==='state');
 ok(sE&&sE.priv&&sE.priv.shop.picks[0]==='GLOVES'&&!JSON.stringify(sE).includes('MIRROR'),'phone E gets only its own picks');
 ok(sM&&sM.priv&&sM.priv.shop.picks[0]==='MIRROR'&&!JSON.stringify(sM).includes('GLOVES'),'phone M gets only its own picks');
 ok(sD&&sD.priv===null&&!JSON.stringify(sD).includes('MIRROR')&&!JSON.stringify(sD).includes('GLOVES'),'director phone sees neither pick');

 console.log('Latency (ping/pong through the computer)');
 const pt=performance.now();Dp.send({type:'ping',t:pt});const pg=await host.wait(m=>m.type==='ping'&&m.cid==='cidD');host.send({type:'pong',cid:'cidD',t:pg.t});
 const pp=await Dp.wait(m=>m.type==='pong');const rtt=performance.now()-pt;ok(!!pp&&rtt<150,`round trip phone → computer → phone ${rtt.toFixed(1)} ms (< 150 ms)`);

 console.log('Reconnect');
 E.ws.close();await E.waitClose();const E2=client({room:'ROOM1',pin:'1234',role:'PLAYER_E',cid:'cidE'});
 const last=await E2.wait(m=>m.type==='state');ok(last&&last.seq===1&&last.priv.shop.picks[0]==='GLOVES','reconnected phone gets the last snapshot immediately');
 E2.send({type:'cmd',id:'e-1',action:'r4.finish',payload:{}});const again=await host.wait(m=>m.type==='cmd'&&m.id==='e-1'&&m!==c1);
 ok(again&&again.id==='e-1','a re-sent command keeps its id (the computer ignores the repeat — tested in the browser test)');
 const E3=client({room:'ROOM1',pin:'1234',role:'PLAYER_E',cid:'cidE'});await E3.wait(m=>m.type==='hello');ok(await E2.waitClose()===4012,'same phone id opened twice → older tab is closed (4012), no double commands');

 console.log('Computer offline');
 host.ws.close();await host.waitClose();const off=await E3.wait(m=>m.type==='host'&&m.online===false);ok(!!off,'phones are told the computer went offline');
 E3.send({type:'cmd',id:'e-2',action:'r4.finish',payload:{}});const na=await E3.wait(m=>m.type==='ack'&&m.id==='e-2');ok(na&&na.ok===false&&na.offline===true,'command while the computer is offline → immediate refusal (never queued for later)');
 const host2=client({room:'ROOM1',pin:'1234',role:'HOST',token:'tok1'});await host2.wait(m=>m.type==='hello');const on=await E3.wait(m=>m.type==='host'&&m.online===true);ok(!!on,'computer reload (same token) → phones see it online again without re-scanning');

 console.log('Kick + close room');
 const pl=await host2.wait(m=>m.type==='peers'&&m.list.some(p=>p.cid==='cidM'));host2.send({type:'kick',cid:'cidM'});ok(await M.waitClose()===4003,'computer removes a phone (4003)');
 host2.send({type:'bye'});ok(await Dp.waitClose()===4011&&await E3.waitClose()===4011,'turning phone mode off closes every phone (4011)');
 const late=client({room:'ROOM1',pin:'1234',role:'PLAYER_E',cid:'z'});ok(await late.waitClose()===4001,'after closing, the old PIN no longer works');
}catch(e){fail++;console.error(e)}finally{srv.kill()}
console.log(`\n${pass} passed, ${fail} failed`);process.exit(fail?1:0);
