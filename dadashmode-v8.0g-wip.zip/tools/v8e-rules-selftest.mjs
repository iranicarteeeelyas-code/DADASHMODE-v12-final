/* node tools/v8e-rules-selftest.mjs · V8.0-e: book §8.5 ties (R1/R4), gloves card in memory room, code re-flash, final sudden death.
   Pure rules + a full simulation of the real show engine (js/v7-core.js) with a tiny stub host. */
import fs from 'node:fs';import vm from 'node:vm';import path from 'node:path';import {fileURLToPath} from 'node:url';
const dir=path.join(path.dirname(fileURLToPath(import.meta.url)),'..');let pass=0,fail=0;
const eq=(n,g,e)=>{const a=JSON.stringify(g),b=JSON.stringify(e);if(a===b){pass++;console.log('✔',n)}else{fail++;console.log('✘',n,'\n   got',a,'\n   exp',b)}};
let NOW=1_000_000;const FakeDate=class extends Date{constructor(...a){a.length?super(...a):super(NOW)}static now(){return NOW}};
const banks={p1:45,p2:45};const journal=[];let idn=0;
const P={players:[{id:'p1',name:'الیاس'},{id:'p2',name:'عماد'}],segments:[]};
const ctx={console,Math,JSON,Object,Array,String,Number,Set,Map,RegExp,Error,Infinity,Promise,Uint8Array,Uint32Array,TextEncoder,Date:FakeDate,
 setInterval:()=>0,setTimeout:()=>0,addEventListener:()=>{},btoa:s=>Buffer.from(s,'binary').toString('base64'),atob:s=>Buffer.from(s,'base64').toString('binary'),
 crypto:{getRandomValues:a=>{for(let i=0;i<a.length;i++)a[i]=(i*2654435761+7)>>>0;return a}},localStorage:{getItem:()=>null,setItem:()=>{}},
 award:(pid,d,reason)=>{banks[pid]+=d;const ev={id:'a'+(++idn),player:pid,delta:d,reason};journal.push(ev);return ev},bankOf:pid=>banks[pid],
 G:()=>({journal}),uid:()=>'u'+(++idn),renderJournal:()=>{},renderScores:()=>{},curSegIndex:()=>0,
 DM5:{P:()=>P,save:()=>{},toast:()=>{},kvPut:()=>{}}};
ctx.window=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
const load=f=>vm.runInContext(fs.readFileSync(path.join(dir,f),'utf8'),ctx,{filename:f});
load('js/v7-rules.js');load('js/v7-core.js');const R=ctx.V7R,V7=ctx.V7;
/* ---- pure ---- */
eq('simul 0.4s = same time',R.simul(12.1,12.5,.5),true);eq('simul 0.5s = not same',R.simul(12,12.5,.5),false);
eq('r1Judge: E done, M started 0.3s later → wait',R.r1Judge({E:10,M:10.3},12.05),{wait:true});
eq('r1Judge: both done within 0.5 → TIE',R.r1Judge({E:10,M:10.3},12.4),{winner:'TIE'});
eq('r1Judge: M 0.8s later → E wins at once',R.r1Judge({E:10,M:10.8},12.0),{winner:'E'});
eq('r1Score tie → both +5 (§8.5)',R.r1Score({tie:true}),{E:5,M:5});
eq('r4Score tie → both +10 (§8.5)',R.r4Score({tie:true}),{E:10,M:10});
eq('sd: closer wins',R.sdResolve({E:{cm:4},M:{cm:9}}).winner,'E');eq('sd: one out',R.sdResolve({E:{out:true},M:{cm:30}}).winner,'M');
eq('sd: both out → repeat',R.sdResolve({E:{out:true},M:{out:true}}).repeat,true);eq('sd: equal → repeat',R.sdResolve({E:{cm:5},M:{cm:5.2}}).repeat,true);
eq('glovesStuck excludes penalties',R.glovesStuck(80,17,0,3),60);
/* ---- engine simulation ---- */
const cmd=(a,p={})=>V7.cmd(a,p,{src:'test'});const tick=()=>{};const S=()=>V7.S();const adv=ms=>{NOW+=ms};
cmd('v7.on');cmd('state.go',{state:'R1'});cmd('r1.start');cmd('r1.valid',{p:'E'});adv(300);cmd('r1.valid',{p:'M'});
// drive the tick by calling the scheduled function indirectly: re-run judge through a zero-length command
const runTick=()=>{/* tick loop is setInterval-stubbed; replicate: */vm.runInContext('void 0',ctx)};
// expose tick: the core's interval callback is private, so emulate by checking after 2s via hold logic
adv(1750);/* E at 2.05s, M at 1.75s → must wait */ 
const H=V7.H;// call internal tick through state.next guard-free path: we re-evaluate using R.r1Judge the same way the engine does
const judge=()=>R.r1Judge(Object.fromEntries(Object.entries(S().r1.hold).map(([k,v])=>[k,v/1000])),V7.vnow()/1000);
eq('engine R1: at 2.05s E, M still holding 0.3s behind → wait',judge(),{wait:true});adv(300);eq('engine R1: then both → TIE',judge(),{winner:'TIE'});
cmd('r1.tie');eq('engine R1 tie via truthcam → 50|50',[banks.p1,banks.p2],[50,50]);
eq('R1 tie cannot be applied twice',cmd('r1.tie').ok,false);cmd('undo');eq('undo R1 tie → both awards reversed in journal',journal.filter(e=>e.kind==='undo').length,2);eq('undo restores state → tie can be re-applied',S().r1.winner!=='TIE',true);banks.p1=45;banks.p2=45;cmd('r1.tie');
// correction after single winner paid
banks.p1=45;banks.p2=45;S().r1={t0:0,run:false,hold:{},winner:'E',layers:{E:0,M:0},done:true};banks.p1+=10;cmd('r1.tie');eq('R1 winner E +10 then truthcam tie → 50|50',[banks.p1,banks.p2],[50,50]);
// R4 simultaneous correct
banks.p1=60;banks.p2=60;cmd('state.go',{state:'R4_GLUE'});cmd('r4.start');adv(40000);cmd('r4.finish',{p:'M'});adv(300);cmd('r4.finish',{p:'E'});cmd('r4.valid');eq('R4 first valid M +15',[banks.p1,banks.p2],[60,75]);
cmd('r4.valid');eq('R4 E valid 0.3s later → both +10 → 70|70',[banks.p1,banks.p2],[70,70]);eq('R4 challenge blocked after tie',cmd('gc.open').ok,false);
banks.p1=60;banks.p2=60;cmd('r4.start');adv(40000);cmd('r4.finish',{p:'M'});adv(2000);cmd('r4.finish',{p:'E'});cmd('r4.valid');cmd('r4.valid');eq('R4 2s apart → only first +15',[banks.p1,banks.p2],[60,75]);
// vault: gloves + reflash
await V7.setLock('472');const eff=S().effects;eff.E.gloves=true;S().vault={armed:false,target:null,pattern:null,riddle:null,order:null,runs:{},rerolls:0,cb:true};
banks.p1=90;banks.p2=80;cmd('state.go',{state:'VAULT_ARMED'});cmd('vault.arm');cmd('state.go',{state:'RUN1'});const k1=S().vault.order[0];
eff[k1].gloves=true;cmd('run.start');cmd('s1.pass');const run=V7.curRun();eq('run at station 2',run.station,2);
eq('gloves off refused before 60s',cmd('run.glovesOff').ok,false);adv(30000);run.clock=V7.clockOf(run);run.runAt=V7.vnow();
cmd('run.pen',{sec:10});eq('penalty not counted as stuck time',Math.round(V7.glovesStuck(run)),30);
adv(31000);/* emulate vaultTick condition */const stuck=V7.glovesStuck(run);eq('stuck ≥ 60 after 61s real',stuck>=60,true);
run.glove={offer:true};const c0=V7.clockOf(run);eq('gloves off allowed after offer',cmd('run.glovesOff').ok,true);eq('−5 applied',Math.round((c0-V7.clockOf(run))*10)/10,5);eq('only once',cmd('run.glovesOff').ok,false);
run.station=4;run.code={lockUntil:0,reflashAt:0};cmd('code.enter',{code:'111'});eq('wrong code → lock 5s',Math.round((run.code.lockUntil-NOW)/1000),5);eq('wrong code → all 3 codes re-flash',!!(run.show&&run.show.all),true);
eq('locked input refused',cmd('code.enter',{code:'472'}).ok,false);adv(5100);cmd('code.enter',{code:'472'});eq('right code opens',run.opened,true);
// sudden death
const other=V7.opp(k1);S().vault.runs[other]={k:other,opened:true,left:run.left,codes:3,done:true,c:[1,1,1]};S().vault.runs[k1].opened=true;
cmd('state.go',{state:'CASE'});eq('equal time → sudden death started',!!(S().cse.sd&&S().cse.sd.on),true);eq('cannot leave CASE without winner',cmd('state.next').ok,false);
cmd('sd.result',{p:'E',out:true});cmd('sd.result',{p:'M',out:true});eq('both out → round 2',S().cse.sd.round,2);
cmd('sd.result',{p:'E',cm:'۷'});cmd('sd.result',{p:'M',cm:12});eq('E closer (Persian digits ok) → winner E',S().cse.winner,'E');eq('why',S().cse.why,'SUDDEN_DEATH_TOKEN');
console.log(`\n${pass} passed, ${fail} failed`);process.exit(fail?1:0);
