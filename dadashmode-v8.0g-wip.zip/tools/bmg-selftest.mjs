/* node tools/bmg-selftest.mjs · Broadcast Motion Graphics: presets, templates, state machine, PVW/PGM, live updates without reset,
   coalescing, no timeline accumulation, interrupt, priority/queue, rollback, rundown, bindings, JSON commands, determinism (spec §5, §9, §17). */
import fs from 'node:fs';import vm from 'node:vm';import path from 'node:path';import {fileURLToPath} from 'node:url';
const dir=path.join(path.dirname(fileURLToPath(import.meta.url)),'..');let pass=0,fail=0;
const ok=(n,c,extra)=>{if(c){pass++;console.log('✔',n)}else{fail++;console.log('✘',n,extra!==undefined?JSON.stringify(extra):'')}};
const ctx={console,Math,JSON,Object,Array,String,Number,Set,Map,RegExp,Error,Infinity,Promise,Date,Float32Array,setTimeout,clearTimeout};ctx.window=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
const load=f=>vm.runInContext(fs.readFileSync(path.join(dir,f),'utf8'),ctx,{filename:f});
['js/bmg/bmg-core.js','js/bmg/bmg-presets.js','js/bmg/bmg-engine.js','js/bmg/bmg-templates.js'].forEach(load);
const B=ctx.BMG,E=B.engine;const step=(s,n=1)=>{for(let i=0;i<n;i++)E.step(s)};const run=(sec)=>step(1/60,Math.ceil(sec*60));
/* presets */
const SPEC12=['slideIn','slideOut','lowerThirdOn','lowerThirdOff','otsReveal','scorebugBuild','scoreIncrement','scoreDecrement','numberRoll','numberPop','rankUp','rankDown','leaderboardReorder','playerCardReveal','teamCardReveal','matchupReveal','winnerReveal','podiumReveal','goalSplash','countdownStart','countdownTick','alertPulse','sponsorSting','tickerStart','tickerStop','stinger','fullscreenTakeover','fullscreenExit','impactBurst','confetti','suspenseReveal','dramaticNumber','hero3d','cameraPush','cameraPull','parallaxReveal','lightSweep','glassReveal','glitchReveal','particleBurst'];
ok('all 40 spec §12 presets exist',SPEC12.every(k=>typeof B.PRESETS[k]==='function'),SPEC12.filter(k=>!B.PRESETS[k]));
let bad=[];for(const k of SPEC12){const tl=B.timeline({clock:B.clocks.PVW});const multi=['matchupReveal','leaderboardReorder','parallaxReveal','podiumReveal'].includes(k);const t=multi?[B.el(),B.el(),B.el()]:k==='winnerReveal'?{bg:B.el(),name:B.el(),sub:B.el(),rays:B.el()}:B.el();try{B.preset(k,tl,t,{at:0,ys:[0,1,2]});tl.seek(tl.totalDuration())}catch(e){bad.push(k+':'+e.message)}}
ok('every preset builds + seeks to its end without error',!bad.length,bad);
{const el=B.el();const tl=B.timeline({clock:B.clocks.PVW});B.PRESETS.slideIn(tl,el,{});tl.seek(tl.totalDuration());ok('slideIn ends settled (x=0, a=1, blur=0)',Math.abs(el.x)<1e-6&&el.a===1&&el.blur===0,el);tl.seek(0);ok('seek(0) returns to the start (a=0)',el.a===0)}
{const el=B.el();const keep=B.motion.durationScale;const a=B.timeline();B.PRESETS.lowerThirdOn(a,el,{});B.motion.durationScale=1.5;const b=B.timeline();B.PRESETS.lowerThirdOn(b,el,{});B.motion.durationScale=keep;ok('durations come from central tokens (tempo 1.5× → 1.5× longer)',b.totalDuration()/a.totalDuration()>1.3)}
/* templates */
const L=B.templateList();ok('≥ 20 templates registered',L.length>=20,L.length);
ok('every template declares explicit renderer + typed schema + version',L.every(t=>['canvas2d','gpu2d','three'].includes(t.renderer)&&t.dataSchema&&/^\d+\.\d+\.\d+$/.test(t.version)));
/* state machine + entrance */
const states=[];const off=B.bus.on('bmg.state',s=>{if(s.id==='sb')states.push(s.to)});
E.show('sb',{E:{name:'الیاس',color:'#ff2738',score:45},M:{name:'عماد',color:'#00c98d',score:45}},{template:'scorebug'});run(2);
ok('show: preroll → entering → live',JSON.stringify(states)===JSON.stringify(['preroll','entering','live']),states);
const sb=E.get('sb');ok('state is live',sb.state==='live');
/* live update: only the changed score animates, no entrance replay */
E.update('sb',{E:{name:'الیاس',color:'#ff2738',score:55}});step(1/60);
ok('update → updating state',sb.state==='updating',sb.state);ok('entrance not replayed (enterCount 1)',sb.enterCount===1);ok('only E score track created',Object.keys(sb.tracks).includes('scoreE')&&!Object.keys(sb.tracks).includes('scoreM'),Object.keys(sb.tracks));
run(3);ok('back to live after update',sb.state==='live',sb.state);ok('plate E settled (s=1)',Math.abs(sb.els.E.s-1)<.01,sb.els.E.s);
/* clock tick: no rebuild */
const tl0=B.activeTimelines();E.update('sb',{clock:{remain:12.3,total:30}});step(1/60);ok('clock-only update creates no timeline',B.activeTimelines()===tl0&&sb.state==='live',{a:B.activeTimelines(),tl0,st:sb.state});
/* coalescing */
const u0=sb.updateCount;for(let i=0;i<50;i++)E.update('sb',{M:{name:'عماد',color:'#00c98d',score:45+i}});step(1/60);ok('50 rapid updates in one frame → 1 update transition',sb.updateCount===u0+1,sb.updateCount-u0);
/* no timeline accumulation */
for(let i=0;i<40;i++){E.update('sb',{E:{name:'الیاس',color:'#ff2738',score:60+i}});step(1/60);E.show('sb',sb.data)}
ok('40 re-triggers keep ≤ 1 timeline per track',E.timelinesOf(sb)<=Object.keys(sb.tracks).length&&Object.keys(sb.tracks).length<=8,{tl:E.timelinesOf(sb),tracks:Object.keys(sb.tracks)});ok('still one entrance',sb.enterCount===1);run(3);
/* interrupt mid-entrance */
E.show('l3',{title:'الیاس'},{template:'lowerThird'});step(1/60,5);ok('lower third entering',E.get('l3').state==='entering');E.interrupt('l3');ok('interrupt → exiting',E.get('l3').state==='exiting');run(1);ok('interrupt completes → hidden, no running timelines',E.get('l3').state==='hidden'&&E.timelinesOf(E.get('l3'))===0);
/* slots, priority, queue */
E.show('intro',{title:'راند ۱'},{template:'segmentIntro',priority:65});run(.2);E.show('mu',{},{template:'matchup',priority:55});ok('lower priority on busy slot → queued',!E.get('mu')||!E.isVisible(E.get('mu')),E.get('mu')&&E.get('mu').state);
ok('queue length 1',Object.values(E.queues).reduce((n,q)=>n+q.length,0)===1);run(7);ok('after intro auto-hides, queued matchup enters',E.isVisible(E.get('mu')),E.get('mu')&&E.get('mu').state);
E.show('win',{name:'الیاس'},{template:'winnerReveal',priority:80});run(.1);ok('higher priority interrupts the slot occupant',E.get('mu').state==='exiting'||E.get('mu').state==='hidden');run(8);E.hide('win');run(1);
/* rollback */
E.update('sb',{E:{name:'الیاس',color:'#ff2738',score:70}});run(2);E.update('sb',{E:{name:'الیاس',color:'#ff2738',score:99}});run(2);E.rollback();run(2);ok('rollback restores previous data (70) without entrance',sb.data.E.score===70&&sb.enterCount===1,{s:sb.data.E.score,e:sb.enterCount});
/* PVW / PGM separation + take */
E.preview('pc',{name:'عماد'},{template:'playerCard'});run(1);ok('preview lives only on PVW',E.isVisible(E.get('pc','PVW'))&&!E.get('pc','PGM'));E.take('pc');run(1);ok('take → same graphic live on PGM',E.isVisible(E.get('pc','PGM'))&&E.get('pc','PGM').data.name==='عماد');
/* states */
ok('setGraphicState alert',E.setState('sb','alert')&&sb.state==='alert');run(1);E.setState('sb','live');ok('back to live',sb.state==='live');ok('emphasis returns to live',E.setState('sb','emphasis')&&(run(1.5),sb.state==='live'),sb.state);
/* trigger action */
E.show('q',{text:'جواب: ۲'},{template:'answerReveal'});run(1);ok('trigger correct → data + mark',E.trigger('q','correct')&&E.get('q').data.correct==='yes');
/* JSON command + rundown */
E.command('{"op":"show","id":"tk","template":"ticker","data":{"items":["a","b"]}}');run(1);ok('JSON command shows ticker',E.isVisible(E.get('tk')));
E.rundownSet([{id:'bg',template:'bug',action:'show'},{id:'bg',action:'hide'}]);E.takeCue();run(1);ok('rundown cue 1 = bug on',E.isVisible(E.get('bg')));E.takeCue();run(1);ok('rundown cue 2 = bug off',E.get('bg').state==='hidden');
/* binding */
let src={remain:9,total:10};E.show('cd',{remain:10,total:10},{template:'countdown'});E.bind('cd',()=>src);run(1);ok('binding pushes live data',E.get('cd').data.remain===9);src={remain:8,total:10};run(.1);ok('binding follows source',E.get('cd').data.remain===8&&E.get('cd').enterCount===1);E.unbind('cd');
/* template versioning */
const v2=Object.assign({},B.template('bug'),{version:'1.1.0'});B.registerTemplate(v2);ok('versioned templates: latest = 1.1.0, 1.0.0 still addressable',B.template('bug').version==='1.1.0'&&B.template('bug','1.0.0').version==='1.0.0');
/* determinism */
const sim=()=>{const el=B.el();const tl=B.timeline({clock:B.clocks.PVW});B.PRESETS.matchupReveal(tl,[el,B.el(),B.el()],{});tl.seek(.37);return JSON.stringify(el)};ok('deterministic choreography (same time → same values)',sim()===sim());
off();console.log(`\n${pass} passed, ${fail} failed`);process.exit(fail?1:0);
