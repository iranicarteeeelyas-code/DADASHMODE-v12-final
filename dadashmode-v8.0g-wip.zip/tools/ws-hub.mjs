/* DADASHMODE V8 · phone mode hub (book §9.2) · zero-dependency WebSocket (RFC 6455) on the same port as the app.
   Rooms: one HOST (the computer = single source of truth) + phones. PIN required. The server stamps the role of every phone
   connection, so a player phone can never pretend to be the director. Private snapshot parts are delivered only to their owner.
   Messages (JSON):
     phone → host : {type:'cmd', id, action, payload, ts}      (server adds role, cid, rx)
     phone → host : {type:'ping', t}                           host answers {type:'pong', t}
     host  → all  : {type:'state', seq, pub, priv:{PLAYER_E, PLAYER_M}}   → each phone receives only priv[its role]
     host  → phone: {type:'ack', cid, id, ok, err, dup}  ·  {type:'pong', cid, t}
     hub   → host : {type:'peers', list}                      hub → phone: {type:'hello', role, room, host} */
import crypto from 'node:crypto';
const GUID='258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const ROLES=['DIRECTOR','PLAYER_E','PLAYER_M','MONITOR','JUDGE'];
const rooms=new Map();
function frame(str,op=1){const p=Buffer.from(str,'utf8');const n=p.length;let h;if(n<126){h=Buffer.from([0x80|op,n])}else if(n<65536){h=Buffer.alloc(4);h[0]=0x80|op;h[1]=126;h.writeUInt16BE(n,2)}else{h=Buffer.alloc(10);h[0]=0x80|op;h[1]=127;h.writeBigUInt64BE(BigInt(n),2)}return Buffer.concat([h,p])}
class Conn{constructor(sock,info){this.sock=sock;Object.assign(this,info);this.buf=Buffer.alloc(0);this.frag=[];this.alive=true;this.open=true;this.since=Date.now();
  sock.on('data',d=>this.onData(d));sock.on('close',()=>this.onClose());sock.on('error',()=>this.onClose());sock.setNoDelay(true)}
 send(obj){if(!this.open)return;try{this.sock.write(frame(typeof obj==='string'?obj:JSON.stringify(obj)))}catch(e){}}
 ping(){if(!this.open)return;try{this.sock.write(Buffer.from([0x89,0]))}catch(e){}}
 close(code=1000,why=''){if(!this.open)return;const r=Buffer.from(why,'utf8').slice(0,120);const p=Buffer.alloc(2+r.length);p.writeUInt16BE(code,0);r.copy(p,2);try{this.sock.write(Buffer.concat([Buffer.from([0x88,p.length]),p]));this.sock.end()}catch(e){}this.onClose()}
 onData(d){this.buf=Buffer.concat([this.buf,d]);for(;;){const b=this.buf;if(b.length<2)return;const fin=(b[0]&0x80)!==0,op=b[0]&15,masked=(b[1]&0x80)!==0;let len=b[1]&127,off=2;
   if(len===126){if(b.length<4)return;len=b.readUInt16BE(2);off=4}else if(len===127){if(b.length<10)return;len=Number(b.readBigUInt64BE(2));off=10}
   if(len>4e6){this.close(1009,'too big');return}const mk=masked?4:0;if(b.length<off+mk+len)return;let pl=b.slice(off+mk,off+mk+len);
   if(masked){const m=b.slice(off,off+4);pl=Buffer.from(pl);for(let i=0;i<pl.length;i++)pl[i]^=m[i&3]}this.buf=b.slice(off+mk+len);
   if(op===8){this.close(1000);return}if(op===9){try{this.sock.write(Buffer.concat([Buffer.from([0x8a,pl.length]),pl]))}catch(e){}continue}if(op===10){this.alive=true;continue}
   if(op===0||op===1||op===2){this.frag.push(pl);if(!fin)continue;const txt=Buffer.concat(this.frag).toString('utf8');this.frag=[];this.alive=true;let msg=null;try{msg=JSON.parse(txt)}catch(e){continue}try{this.onMsg&&this.onMsg(msg)}catch(e){console.warn('[hub]',e.message)}}}}
 onClose(){if(!this.open)return;this.open=false;try{this.sock.destroy()}catch(e){}this.onEnd&&this.onEnd()}}
function room(id){if(!rooms.has(id))rooms.set(id,{id,pin:null,token:null,host:null,phones:new Map(),last:null});return rooms.get(id)}
function peers(r){return [...r.phones.values()].map(c=>({cid:c.cid,role:c.role,name:c.name||'',ua:c.ua||'',since:c.since,ip:c.ip}))}
function tellHost(r){if(r.host)r.host.send({type:'peers',list:peers(r)})}
function forPhone(r,c,st){if(!st)return null;const priv=st.priv&&st.priv[c.role]||null;return {type:'state',seq:st.seq,pub:st.pub,priv}}
export function attachHub(server){
 server.on('upgrade',(req,sock)=>{const u=new URL(req.url,'http://x');if(u.pathname!=='/ws'){sock.destroy();return}
  const key=req.headers['sec-websocket-key'];if(!key){sock.destroy();return}
  const acc=crypto.createHash('sha1').update(key+GUID).digest('base64');
  sock.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${acc}\r\n\r\n`);
  const q=Object.fromEntries(u.searchParams);const rid=String(q.room||'').toUpperCase().slice(0,8),pin=String(q.pin||''),role=String(q.role||'').toUpperCase();
  const ip=(req.socket.remoteAddress||'').replace('::ffff:','');const c=new Conn(sock,{cid:q.cid||crypto.randomUUID().slice(0,8),role,ip,ua:String(req.headers['user-agent']||'').slice(0,80),name:String(q.name||'').slice(0,24)});
  if(!/^[A-Z0-9]{4,8}$/.test(rid)||!/^\d{4}$/.test(pin)){c.close(4000,'bad room/pin');return}
  const r=room(rid);
  if(role==='HOST'){if(r.host&&r.host.open&&r.token&&q.token!==r.token){c.close(4009,'another computer is host');return}
   if(r.host&&r.host!==c){const old=r.host;r.host=null;old.close(4010,'replaced')}
   r.pin=pin;r.token=q.token||r.token;r.host=c;c.onMsg=m=>{
     if(m.type==='state'){r.last=m;for(const p of r.phones.values())p.send(forPhone(r,p,m));return}
     if((m.type==='ack'||m.type==='pong'||m.type==='to')&&m.cid){const p=r.phones.get(m.cid);if(p)p.send(m);return}
     if(m.type==='kick'&&m.cid){const p=r.phones.get(m.cid);if(p)p.close(4003,'removed by host');return}
     if(m.type==='bye'){for(const p of r.phones.values())p.close(4011,'room closed');r.pin=null;r.last=null;return}};
   c.onEnd=()=>{if(r.host===c){r.host=null;for(const p of r.phones.values())p.send({type:'host',online:false})}};
   c.send({type:'hello',role:'HOST',room:rid});tellHost(r);for(const p of r.phones.values())p.send({type:'host',online:true});return}
  if(!ROLES.includes(role)){c.close(4002,'bad role');return}
  if(!r.pin||r.pin!==pin){c.close(4001,'wrong PIN');return}
  const prev=r.phones.get(c.cid);if(prev&&prev!==c){prev.onEnd=null;prev.close(4012,'reconnected')}
  r.phones.set(c.cid,c);
  c.onMsg=m=>{if(m.type==='cmd'){if(!r.host){c.send({type:'ack',id:m.id,ok:false,err:'کامپیوتر وصل نیست',offline:true});return}
     r.host.send({type:'cmd',id:String(m.id||''),action:String(m.action||''),payload:m.payload||{},ts:m.ts,rx:Date.now(),role:c.role,cid:c.cid});return}
   if(m.type==='ping'){if(r.host)r.host.send({type:'ping',t:m.t,cid:c.cid,role:c.role});else c.send({type:'pong',t:m.t,host:false});return}};
  c.onEnd=()=>{if(r.phones.get(c.cid)===c)r.phones.delete(c.cid);tellHost(r)};
  c.send({type:'hello',role:c.role,room:rid,cid:c.cid,host:!!(r.host&&r.host.open)});if(r.last)c.send(forPhone(r,c,r.last));tellHost(r)});
 setInterval(()=>{for(const r of rooms.values()){for(const c of [r.host,...r.phones.values()]){if(!c)continue;if(!c.alive){c.close(1001,'timeout');continue}c.alive=false;c.ping()}}},15000).unref();
 return {rooms,status:()=>[...rooms.values()].map(r=>({room:r.id,host:!!(r.host&&r.host.open),phones:peers(r)}))}}
