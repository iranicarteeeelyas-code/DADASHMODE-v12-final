/* DADASHMODE V8 · v8-games.js · data-driven game engine for NEW games (anything the book invents that the V7 modules don't cover).
   A game = a "play" segment with game="generic" and an "engine" block (from the .ml file or the segment inspector).
   Pure scoring core (V8G.score) runs in Node for tools/v8-games-selftest.mjs; the runtime uses the ONLY bank writer award()
   and the on-screen timer st.timer (same clock the stage already draws), so graphics, journal, CSV and VAR keep working.

   engine = {
    mode: "first" | "points" | "metric" | "judge",
    limit: seconds (0 = no time limit; default = segment duration),
    reward: winner award (default = segment reward),
    fallback: award when nobody finished ("first") → more progress wins (equal → nothing),
    tie: {band: seconds or metric units, award: points each; 0 = nobody gets anything},
    metric: {label:"متر", better:"higher"|"lower", scale:"fixed"|"diff", factor:1, floor:3, cap:20, dnf:"last"},
    events: [{id,label,value,max}]   // "points": each press adds value to that player's round score (max = per-player cap)
    award: "winner" | "sum",          // "points": winner gets reward, or every player gets his own sum
    penalties: [{id,label,value}],    // any mode: applied straight to the bank (negative value)
    loser: 0,                         // extra points for the loser (negative = penalty)
    maxAward: null                    // clamp any single award
   }                                                                                                     */
(function(root){'use strict';
const MODES={first:'اولین نفری که تمام کند',points:'جمع امتیاز رویدادها',metric:'بهترین عدد (زمان/فاصله/تعداد)',judge:'انتخاب داور'};
const num=(x,d)=>Number.isFinite(+x)?+x:d;
const r1=x=>Math.round(x*10)/10;
function norm(e,seg){e=e||{};seg=seg||{};const mode=MODES[e.mode]?e.mode:'judge';
 const t=e.tie||{};const m=e.metric||{};
 return {mode,limit:num(e.limit,num(seg.duration,0)),reward:num(e.reward,num(seg.reward,10)),fallback:num(e.fallback,0),
  tie:{band:num(t.band,mode==='first'?0.5:0),award:num(t.award,0)},
  metric:{label:String(m.label||''),better:m.better==='lower'?'lower':'higher',scale:m.scale==='diff'?'diff':'fixed',factor:num(m.factor,1),floor:num(m.floor,0),cap:num(m.cap,Infinity),dnf:'last'},
  events:(Array.isArray(e.events)?e.events:[]).map((x,i)=>({id:String(x.id||('e'+i)),label:String(x.label||x.id||('رویداد '+(i+1))),value:num(x.value,1),max:x.max==null?Infinity:num(x.max,Infinity)})),
  award:e.award==='sum'?'sum':'winner',
  penalties:(Array.isArray(e.penalties)?e.penalties:[]).map((x,i)=>({id:String(x.id||('p'+i)),label:String(x.label||'خطا'),value:-Math.abs(num(x.value,1))})),
  loser:num(e.loser,0),maxAward:e.maxAward==null?null:num(e.maxAward,null)}}
function check(e){const W=[],E=[];if(!e||typeof e!=='object'){E.push('engine باید شیء باشد');return {errors:E,warnings:W}}
 if(!MODES[e.mode])E.push(`engine.mode نامعتبر «${e.mode}» (مجاز: ${Object.keys(MODES).join(', ')})`);
 if(e.mode==='points'&&!(Array.isArray(e.events)&&e.events.length))E.push('engine.mode=points بدون events');
 if(e.mode==='metric'&&!(e.metric&&e.metric.label))W.push('engine.metric.label خالی است (مثلاً «متر» یا «ثانیه»)');
 if(e.metric&&e.metric.better&&!['higher','lower'].includes(e.metric.better))E.push('engine.metric.better باید higher یا lower باشد');
 const ids=new Set();[...(e.events||[]),...(e.penalties||[])].forEach(x=>{if(x&&x.id){if(ids.has(x.id))E.push(`engine: شناسهٔ تکراری «${x.id}»`);ids.add(x.id)}});
 ['limit','reward','fallback'].forEach(k=>{if(e[k]!=null&&!Number.isFinite(+e[k]))E.push(`engine.${k} عدد نیست`)});
 return {errors:E,warnings:W}}
/* rec = {finish:{E:sec,M:sec}, progress:{E,M}, events:{E:[id..],M:[id..]}, metric:{E:number|null,M}, pick:'E'|'M'|'tie'|'none'} */
function score(spec,rec){const s=spec.mode?spec:norm(spec);rec=rec||{};const K=['E','M'];const aw={E:0,M:0};let winner=null,note='';
 const add=(k,v)=>{aw[k]+=v};const other=k=>k==='E'?'M':'E';
 const tieOr=(a,b,better)=>{/* returns 'E'|'M'|'TIE' */const d=Math.abs(a-b);if(d<=s.tie.band&&(s.tie.band>0||a===b))return 'TIE';return better==='lower'?(a<b?'E':'M'):(a>b?'E':'M')};
 if(s.mode==='first'){const f=rec.finish||{};const has=K.filter(k=>Number.isFinite(f[k])&&(!s.limit||f[k]<=s.limit));
  if(has.length===2){const w=tieOr(f.E,f.M,'lower');if(w==='TIE'){winner='TIE';note='TIE'}else{winner=w;note='FIRST'}}
  else if(has.length===1){winner=has[0];note='FIRST'}
  else{const p=rec.progress||{};const a=num(p.E,0),b=num(p.M,0);if(a!==b&&s.fallback){winner=a>b?'E':'M';note='FALLBACK_PROGRESS';add(winner,s.fallback)}else note='NOBODY'}
  if(note==='FIRST')add(winner,s.reward);if(note==='TIE')K.forEach(k=>add(k,s.tie.award))}
 else if(s.mode==='points'){const ev=rec.events||{};const sums={};K.forEach(k=>{const cnt={};sums[k]=0;(ev[k]||[]).forEach(id=>{const e=s.events.find(x=>x.id===id);if(!e)return;cnt[id]=(cnt[id]||0)+1;if(cnt[id]<=e.max)sums[k]+=e.value})});
  if(s.award==='sum'){K.forEach(k=>add(k,sums[k]));note='SUM';winner=sums.E===sums.M?'TIE':(sums.E>sums.M?'E':'M')}
  else{const w=tieOr(sums.E,sums.M,'higher');if(w==='TIE'){winner='TIE';note='TIE';if(sums.E||sums.M)K.forEach(k=>add(k,s.tie.award))}else{winner=w;note='MORE_POINTS';add(w,s.reward)}}
  rec._sums=sums}
 else if(s.mode==='metric'){const m=rec.metric||{};const v=K.map(k=>Number.isFinite(+m[k])&&m[k]!==null&&m[k]!==''?+m[k]:null);
  if(v[0]==null&&v[1]==null)note='NOBODY';
  else if(v[0]==null||v[1]==null){winner=v[0]==null?'M':'E';note='ONLY_ONE';add(winner,s.metric.scale==='diff'?Math.min(s.metric.cap,Math.max(s.metric.floor,s.reward)):s.reward)}
  else{const w=tieOr(v[0],v[1],s.metric.better);if(w==='TIE'){winner='TIE';note='TIE';K.forEach(k=>add(k,s.tie.award))}
   else{winner=w;note='BETTER';let pts=s.reward;if(s.metric.scale==='diff'){pts=Math.round(Math.abs(v[0]-v[1])*s.metric.factor);pts=Math.min(s.metric.cap,Math.max(s.metric.floor,pts))}add(w,pts)}}}
 else{const p=rec.pick;if(p==='E'||p==='M'){winner=p;note='JUDGE';add(p,s.reward)}else if(p==='tie'){winner='TIE';note='TIE';K.forEach(k=>add(k,s.tie.award))}else note='NOBODY'}
 if(s.loser&&(winner==='E'||winner==='M'))add(other(winner),s.loser);
 if(s.maxAward!=null)K.forEach(k=>{aw[k]=Math.min(aw[k],s.maxAward)});
 const pen={E:0,M:0};const pe=rec.penaltiesHit||{};K.forEach(k=>(pe[k]||[]).forEach(id=>{const p=s.penalties.find(x=>x.id===id);if(p)pen[k]+=p.value}));
 K.forEach(k=>{aw[k]=r1(aw[k]+pen[k])});
 const awards={};K.forEach(k=>{if(aw[k])awards[k]=aw[k]});return {awards,winner,note,penalties:pen,sums:rec._sums}}
const V8G={MODES,norm,check,score};root.V8G=V8G;if(typeof module!=='undefined'&&module.exports)module.exports=V8G;

/* ================= runtime (browser) ================= */
if(typeof document==='undefined')return;
const E_=n=>{try{return (0,eval)(n)}catch(e){return undefined}};
const P_=()=>E_('P');const ST=()=>E_('st');
const fa=n=>String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]).replace(/\./g,'٫');
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const toast=m=>{try{E_('toast')(m)}catch(e){}};
const player=k=>{const p=P_();return p&&p.players&&p.players[k==='E'?0:1]};
const seg=()=>{const p=P_();const i=E_('curSegIndex');return p&&typeof i==='function'?p.segments[i()]:null};
const isGame=s=>s&&s.type==='play'&&s.engine&&MODES[s.engine.mode]&&!s.v7;
function store(s){const p=P_();p.v8g=p.v8g||{};return p.v8g[s.id]||(p.v8g[s.id]={run:false,t0:0,finish:{},progress:{},events:{E:[],M:[]},penaltiesHit:{E:[],M:[]},metric:{E:null,M:null},pick:null,applied:[],result:null,log:[]})}
const save=()=>{try{E_('save')()}catch(e){}};
const logJ=text=>{try{const G=E_('G'),uid=E_('uid');G().journal.push({id:uid(),t:Date.now(),kind:'v8g',player:null,delta:0,reason:text,seg:E_('curSegIndex')()});E_('renderJournal')()}catch(e){console.log('[V8G]',text)}};
function elapsed(r){const st=ST();const s=seg();if(st&&st.timer&&st.live>=0&&P_().segments[st.live]===s)return r1(st.timer.total-st.timer.remain);return r.t0?r1((Date.now()-r.t0)/1000):0}
function startTimer(s,spec){const st=ST();if(!st)return;const d=spec.limit||s.duration||30;st.timer={total:d,remain:d,running:true,lastSec:99}}
const CMD={
 start(s,spec,r){r.run=true;r.t0=Date.now();r.finish={};r.result=null;startTimer(s,spec);logJ(`بازی جدید «${s.title}» شروع`);try{E_('AE').whistle()}catch(e){}},
 finish(s,spec,r,p){if(r.finish[p.k]!=null)return;r.finish[p.k]=elapsed(r);logJ(`${player(p.k).name} تمام کرد ${fa(r.finish[p.k])} ثانیه`);if(Object.keys(r.finish).length===2){r.run=false;const st=ST();if(st)st.timer.running=false}},
 unfinish(s,spec,r,p){delete r.finish[p.k]},
 ev(s,spec,r,p){const e=spec.events.find(x=>x.id===p.id);if(!e)return;const n=r.events[p.k].filter(x=>x===p.id).length;if(n>=e.max){toast(`سقف «${e.label}» پر شده`);return}r.events[p.k].push(p.id);try{e.value>=0?E_('AE').ding():E_('AE').lose()}catch(_){}},
 pen(s,spec,r,p){r.penaltiesHit[p.k].push(p.id);logJ(`${player(p.k).name} · ${(spec.penalties.find(x=>x.id===p.id)||{}).label}`);try{E_('AE').buzzer()}catch(_){}},
 pop(s,spec,r,p){const a=r.events[p.k];if(a.length)a.pop()},
 metric(s,spec,r,p){r.metric[p.k]=p.v===''||p.v==null?null:+p.v},
 progress(s,spec,r,p){r.progress[p.k]=+p.v||0},
 pick(s,spec,r,p){r.pick=p.v},
 stop(s,spec,r){r.run=false;const st=ST();if(st&&st.timer)st.timer.running=false},
 apply(s,spec,r){if(r.applied.length){toast('امتیاز این بازی قبلاً ثبت شده؛ اول «برگرداندن» را بزنید');return}CMD.stop(s,spec,r);
  const res=score(spec,r);r.result=res;const award=E_('award');
  for(const k of ['E','M']){const v=res.awards[k];if(!v)continue;const ev=award(player(k).id,v,`${s.title} · ${noteFa(res.note)}`,{force:true});if(ev)r.applied.push(ev.id)}
  logJ(`نتیجهٔ «${s.title}»: ${noteFa(res.note)} ${Object.entries(res.awards).map(([k,v])=>player(k).name+' '+(v>0?'+':'')+fa(v)).join(' · ')||'بدون امتیاز'}`)},
 revert(s,spec,r){const G=E_('G'),uid=E_('uid');for(const id of r.applied){const e=G().journal.find(x=>x.id===id);G().journal.push({id:uid(),t:Date.now(),kind:'undo',ref:id,player:e&&e.player,delta:0,reason:'برگرداندن بازی جدید: '+s.title,seg:E_('curSegIndex')()})}r.applied=[];r.result=null;try{E_('renderScores')();E_('renderJournal')()}catch(e){}},
 reset(s,spec,r){if(r.applied.length)CMD.revert(s,spec,r);const p=P_();delete p.v8g[s.id]}};
function noteFa(n){return {FIRST:'اولین تمام‌کننده',TIE:'تساوی',FALLBACK_PROGRESS:'هیچ‌کس تمام نکرد · پیشرفت بیشتر',NOBODY:'بدون برنده',SUM:'جمع امتیاز',MORE_POINTS:'امتیاز بیشتر',ONLY_ONE:'فقط یک نفر نتیجه داشت',BETTER:'نتیجهٔ بهتر',JUDGE:'انتخاب داور'}[n]||n}
function run(a,p){const s=seg();if(!isGame(s))return;const spec=norm(s.engine,s);const r=store(s);CMD[a]&&CMD[a](s,spec,r,p||{});save();render()}
function deck(s){const spec=norm(s.engine,s),r=store(s);const B=(a,label,p,cls)=>`<button class="btn sm ${cls||''}" data-v8g="${a}" data-v8p='${esc(JSON.stringify(p||{}))}'>${label}</button>`;
 const row=h=>`<div class="row">${h}</div>`;const prev=score(spec,JSON.parse(JSON.stringify(r)));
 let h=`<div class="game-box"><h4>${esc(s.title)} <span class="muted">· بازی جدید · ${esc(MODES[spec.mode])}${spec.limit?' · '+fa(spec.limit)+' ثانیه':''}</span></h4>`;
 if((s.rules||[]).length)h+=`<p class="muted" style="margin:0">${s.rules.map(esc).join(' · ')}</p>`;
 h+=row((r.run?B('stop','⏸ توقف'):B('start',r.result?'شروع دوباره':'▶ شروع','', 'pri'))+`<span class="muted" id="v8gT"></span>`);
 for(const k of ['E','M']){const pl=player(k);if(!pl)continue;let x=`<b style="color:${pl.color}">${esc(pl.symbol+' '+pl.name)}</b>`;
  if(spec.mode==='first'){x+=r.finish[k]!=null?`<span>✔ ${fa(r.finish[k])} ث</span>${B('unfinish','لغو',{k})}`:B('finish','✓ تمام کرد (معتبر)',{k},'ok');if(spec.fallback)x+=`<label class="muted">پیشرفت <input type="number" style="width:64px" data-v8in="progress" data-k="${k}" value="${r.progress[k]??''}"></label>`}
  if(spec.mode==='points'){x+=spec.events.map(e=>B('ev',`${esc(e.label)} ${e.value>=0?'+':''}${fa(e.value)}${Number.isFinite(e.max)?' ('+fa(r.events[k].filter(i=>i===e.id).length)+'/'+fa(e.max)+')':''}`,{k,id:e.id},e.value>=0?'ok':'')).join('')+B('pop','↶',{k})+`<b>جمع ${fa((prev.sums||{})[k]||0)}</b>`}
  if(spec.mode==='metric')x+=`<label>${esc(spec.metric.label||'نتیجه')} <input type="number" step="0.1" style="width:80px" data-v8in="metric" data-k="${k}" value="${r.metric[k]??''}"></label><span class="muted">${spec.metric.better==='lower'?'کمتر بهتر':'بیشتر بهتر'}</span>`;
  if(spec.mode==='judge')x+=B('pick','برنده',{v:k},r.pick===k?'pri':'');
  x+=spec.penalties.map(p=>B('pen',`${esc(p.label)} ${fa(p.value)}`,{k,id:p.id})).join('');h+=row(x)}
 if(spec.mode==='judge')h+=row(B('pick','تساوی',{v:'tie'},r.pick==='tie'?'pri':'')+B('pick','بدون برنده',{v:'none'},r.pick==='none'?'pri':''));
 const pv=Object.entries(prev.awards).map(([k,v])=>`${esc(player(k).name)} ${v>0?'+':''}${fa(v)}`).join(' · ')||'بدون امتیاز';
 h+=`<p style="margin:4px 0">${r.result?'<b>ثبت شد:</b> ':'<span class="muted">پیش‌نمایش نتیجه:</span> '}${esc(noteFa(prev.note))} · ${pv}</p>`;
 h+=row((r.applied.length?B('revert','برگرداندن امتیاز این بازی'):B('apply','محاسبه و ثبت امتیاز ✓','','ok'))+B('reset','پاک کردن این بازی'))+'</div>';return h}
function render(){const s=seg();const el=document.getElementById('gameDeck');if(!el||!isGame(s))return false;el.innerHTML=deck(s);try{E_('renderQuickLines')()}catch(e){}return true}
function hook(){const f=E_('renderGameDeck');if(typeof f!=='function'||!P_())return setTimeout(hook,250);
 (0,eval)('renderGameDeck=(function(_r){return function(){try{if(window.V8G&&V8G._render())return}catch(e){console.warn("[V8G]",e)}return _r.apply(this,arguments)}})(renderGameDeck)');
 try{E_('renderGameDeck')()}catch(e){}}
V8G._render=render;V8G.run=run;
/* phone mode (§9.2): public state of the new game on air, for remote.html (director / judge / players) */
V8G.phone=()=>{const s=seg();if(!isGame(s))return null;const spec=norm(s.engine,s),r=store(s);const prev=score(spec,JSON.parse(JSON.stringify(r)));const fin=v=>Number.isFinite(v)?v:null;
 const cnt=k=>{const o={};(r.events[k]||[]).forEach(id=>{o[id]=(o[id]||0)+1});return o};
 return {id:s.id,title:s.title,rules:(s.rules||[]).slice(0,6),mode:spec.mode,modeFa:MODES[spec.mode],limit:spec.limit,run:!!r.run,elapsed:r.run?elapsed(r):null,finish:r.finish,
  events:spec.events.map(e=>({id:e.id,label:e.label,value:e.value,max:fin(e.max)})),counts:{E:cnt('E'),M:cnt('M')},penalties:spec.penalties.map(p=>({id:p.id,label:p.label,value:p.value})),
  metric:{label:spec.metric.label,better:spec.metric.better,E:r.metric.E,M:r.metric.M},fallback:!!spec.fallback,progress:r.progress,pick:r.pick,applied:r.applied.length>0,
  preview:{note:noteFa(prev.note),awards:prev.awards,sums:prev.sums||null},result:r.result?{note:noteFa(r.result.note),awards:r.result.awards}:null}};
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('#gameDeck [data-v8g]');if(!b)return;e.preventDefault();e.stopPropagation();try{E_('AE').resume()}catch(_){}run(b.dataset.v8g,JSON.parse(b.dataset.v8p||'{}'))},true);
document.addEventListener('change',e=>{const t=e.target;if(t&&t.dataset&&t.dataset.v8in)run(t.dataset.v8in,{k:t.dataset.k,v:t.value.replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d))})},true);
setInterval(()=>{const el=document.getElementById('v8gT');const s=seg();if(!el||!isGame(s))return;const r=store(s);el.textContent=r.run?'زمان '+fa(elapsed(r).toFixed(1)):''},250);
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',hook);else hook();
})(typeof globalThis!=='undefined'?globalThis:window);
