/* DADASHMODE V8 · v8-sync.js · phone mode HOST client (book §9.2). The computer stays the single source of truth.
   - pairing drawer (F2 or 📱 in the dock): room + 4-digit PIN, QR per role (http://<LAN-IP>:<port>/remote.html?room=..&pin=..&role=..)
   - WebSocket to tools/ws-hub.mjs on the same port; auto-reconnect; the hub stamps every phone's role (a player can never act as director)
   - every phone command → V7.cmd (idempotent ids, role check, UNDO, journal) or a host action (subtitles, classic segments, new-game engine,
     graphics style). Ack back to the phone. Every phone command is written to the journal with role + id (secret picks without the card).
   - state push: {type:'state', seq, pub, priv}; the hub forwards priv[role] only to its owner. 4 Hz while phones are connected.
   - same device without a server: BroadcastChannel 'dadashmode-sync' (remote.html in another tab/window).                         */
(function(){'use strict';
const D=window.DM5,esc=D.esc,fa=D.fa;
const LS='dm-sync-v8';const EV=n=>{try{return (0,eval)(n)}catch(e){return undefined}};
const ALPH='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const rnd=n=>crypto.getRandomValues(new Uint32Array(n));
const genRoom=()=>Array.from(rnd(4),x=>ALPH[x%ALPH.length]).join('');
const genPin=()=>String(1000+rnd(1)[0]%9000);
const ROLES=[['DIRECTOR','🎬 کارگردان'],['PLAYER_E','🔴 بازیکن E'],['PLAYER_M','🟢 بازیکن M'],['JUDGE','⚖️ داور سوم'],['MONITOR','🖥 مانیتور']];
const roleFa=r=>(ROLES.find(x=>x[0]===r)||[r,r])[1];
let C={};try{C=JSON.parse(localStorage.getItem(LS)||'{}')}catch(e){}
if(!/^[A-Z0-9]{4,8}$/.test(C.room||''))C.room=genRoom();if(!/^\d{4}$/.test(C.pin||''))C.pin=genPin();if(!C.token)C.token=Array.from(rnd(4),x=>x.toString(36)).join('');
const saveC=()=>{try{localStorage.setItem(LS,JSON.stringify(C))}catch(e){}};saveC();
const S={ws:null,status:'off',err:'',peers:[],seq:0,retry:0,timer:null,server:null,ips:[],port:location.port||'',log:[],bc:null,ids:[],lastSend:0,pend:null};
const SY=window.V8SYNC={C,S,ROLES};

/* ---------- which actions exist outside the V7 engine (host actions) and who may send them ---------- */
const V8G_JUDGE=['finish','unfinish','ev','pen','pop','metric','progress','pick'];
const V8G_DIR=V8G_JUDGE.concat(['start','stop','apply','revert','reset']);
const HOST={
 'sub.toggle':{roles:['DIRECTOR'],run:()=>{V7SUB.CFG.on=!V7SUB.CFG.on;V7SUB.save();return {ok:true,msg:V7SUB.CFG.on?'زیرنویس روشن':'زیرنویس خاموش'}}},
 'sub.spk':{roles:['DIRECTOR'],run:p=>{const c=V7SUB.CFG;if(!c.spk||!(p.k in c.spk))return {ok:false,err:'گوینده نامعتبر'};c.spk[p.k]=!c.spk[p.k];V7SUB.save();return {ok:true}}},
 'sub.cps':{roles:['DIRECTOR'],run:p=>{const c=V7SUB.CFG;const v=p.v!=null?+p.v:(+c.cps||15)+(+p.d||0);c.cps=Math.max(8,Math.min(25,Math.round(v)));V7SUB.save();return {ok:true}}},
 'sub.mode':{roles:['DIRECTOR'],run:p=>{if(!['all','word','typewriter','karaoke'].includes(p.m))return {ok:false,err:'حالت نامعتبر'};V7SUB.CFG.mode=p.m;V7SUB.save();return {ok:true}}},
 'seg.next':{roles:['DIRECTOR'],run:()=>segGo(+1)},'seg.prev':{roles:['DIRECTOR'],run:()=>segGo(-1)},
 'seg.go':{roles:['DIRECTOR'],run:p=>segGo(0,+p.i)},
 'seg.toggle':{roles:['DIRECTOR'],run:()=>{const f=EV('togglePlay');if(typeof f!=='function')return {ok:false,err:'پخش در دسترس نیست'};f();return {ok:true}}},
 'seg.stop':{roles:['DIRECTOR'],run:()=>{const f=EV('stopAll');if(typeof f!=='function')return {ok:false,err:'پخش در دسترس نیست'};f();return {ok:true}}},
 'gfx.style':{roles:['DIRECTOR'],run:p=>{if(!window.BMGB)return {ok:false,err:'سیستم گرافیک پخش بارگذاری نشده'};BMGB.setStyle(p.v==='broadcast'?'broadcast':'classic');return {ok:true}}}};
function segGo(d,abs){const P=D.P(),st=D.st(),go=EV('goLive');if(!P||!st||typeof go!=='function')return {ok:false,err:'قسمت باز نیست'};
 const cur=st.live>=0?st.live:st.sel;const i=abs!=null&&Number.isFinite(abs)?abs:cur+d;if(i<0||i>=P.segments.length)return {ok:false,err:'بخش دیگری نیست'};go(i);return {ok:true}}
const SECRET=new Set(['shop.pick','shop.none','risk.stake']);/* never write the chosen card/stake to the on-screen journal */

SY.exec=(action,payload,meta)=>{action=String(action||'');payload=payload&&typeof payload==='object'?payload:{};const role=meta.role||'DIRECTOR';const id=meta.id?String(meta.id):'';
 const src='phone-'+(role==='PLAYER_E'?'E':role==='PLAYER_M'?'M':role==='DIRECTOR'?'D':role==='JUDGE'?'J':role)+(meta.via==='bc'?'·tab':'');
 const note=(ok,err)=>{const line=`PHONE ${roleFa(role).replace(/^\S+\s/,'')} ${action}${SECRET.has(action)?'':' '+short(payload)} #${id.slice(-6)} ${ok?'OK':'✕ '+(err||'')}`;
  S.log.unshift({t:Date.now(),role,action,ok,err:err||''});S.log.length=Math.min(S.log.length,40);try{if(window.V7)V7.log(line,src)}catch(e){}};
 if(role==='MONITOR'){note(false,'مانیتور دکمه ندارد');return {ok:false,err:'مانیتور فقط نمایش است'}}
 /* host actions + new-game engine: own idempotency list (V7.cmd keeps its own) */
 const isV8g=action.startsWith('v8g.');const h=HOST[action];
 if(h||isV8g){if(id){if(S.ids.includes(id))return {ok:true,dup:true};S.ids.push(id);if(S.ids.length>600)S.ids.splice(0,200)}
  let res;
  if(isV8g){const a=action.slice(4);const allowed=role==='DIRECTOR'?V8G_DIR:role==='JUDGE'?V8G_JUDGE:(role==='PLAYER_E'||role==='PLAYER_M')?['finish']:[];
   if(!allowed.includes(a))res={ok:false,err:'اجازه ندارید'};
   else{if(role==='PLAYER_E'||role==='PLAYER_M'){const me=role.slice(-1);if(payload.k&&payload.k!==me)res={ok:false,err:'اجازه ندارید'};else payload=Object.assign({},payload,{k:me})}
    if(!res){if(!window.V8G||!V8G.phone||!V8G.phone())res={ok:false,err:'بازی جدیدی روی آنتن نیست'};else{try{V8G.run(a,payload);res={ok:true}}catch(e){res={ok:false,err:e.message}}}}}}
  else if(!h.roles.includes(role))res={ok:false,err:'اجازه ندارید'};
  else{try{res=h.run(payload)||{ok:true}}catch(e){res={ok:false,err:e.message}}}
  note(res.ok!==false,res.err);push(true);return res}
 if(!window.V7)return {ok:false,err:'موتور V7 بارگذاری نشده'};
 const res=V7.cmd(action,payload,{id,role,src})||{ok:true};if(!res.dup)note(res.ok!==false,res.err);push(true);return res};
const short=p=>{const s=Object.entries(p||{}).filter(([k])=>k!=='p').map(([k,v])=>k+'='+(typeof v==='object'?JSON.stringify(v):v)).join(',');const k=p&&p.p?p.p+' ':'';return (k+s).slice(0,40)};

/* ---------- snapshot = V7.snapshot() + what the phones need beyond V7 ---------- */
SY.snapshot=()=>{let base={pub:{},priv:{}};try{if(window.V7&&V7.snapshot)base=V7.snapshot()}catch(e){console.warn('[sync] snapshot',e)}
 const pub=Object.assign({},base.pub);const P=D.P(),st=D.st();
 pub.now=Date.now();pub.v7on=!!(window.V7&&V7.S().on);
 if(window.V7&&V7.R){pub.cards=V7.R.CARDS.map(c=>({id:c.id,fa:c.fa,icon:c.icon,color:c.color,line:c.line,sub:c.sub}));pub.states=V7.R.STATES.map(s=>[s,V7.R.STATE_FA[s]])}
 if(P&&st){pub.seg={title:P.title||P.name||'',live:st.live,sel:st.sel,playing:!!st.playing,list:(P.segments||[]).map(s=>({t:s.title||s.type,type:s.type,game:!!(s.engine&&!s.v7)})),
  timer:st.live>=0&&P.segments[st.live]&&P.segments[st.live].type==='play'?{remain:+(+st.timer.remain||0).toFixed(1),total:st.timer.total,running:!!st.timer.running}:null};
  if(!pub.names){const ps=P.players||[];pub.names={E:(ps[0]&&ps[0].name)||'E',M:(ps[1]&&ps[1].name)||'M'};pub.colors={E:(ps[0]&&ps[0].color)||'#ff2738',M:(ps[1]&&ps[1].color)||'#00c98d'}}
  if(!pub.banks){try{const b=EV('bankOf');pub.banks={E:b(P.players[0].id),M:b(P.players[1].id)}}catch(e){}}}
 try{pub.v8g=window.V8G&&V8G.phone?V8G.phone():null}catch(e){pub.v8g=null}
 if(window.V7SUB){pub.subsCfg={on:V7SUB.CFG.on,cps:V7SUB.CFG.cps,mode:V7SUB.CFG.mode,spk:Object.assign({},V7SUB.CFG.spk||{})}}
 pub.gfx=window.BMGB?BMGB.S.style:null;
 return {pub,priv:base.priv||{}}};

/* ---------- state push (throttled, heartbeat 4 Hz while anyone listens) ---------- */
function listeners(){return (S.ws&&S.ws.readyState===1&&S.peers.length>0)||!!S.bcSeen}
function push(now){if(!listeners())return;const t=performance.now();if(!now&&t-S.lastSend<60){if(!S.pend)S.pend=setTimeout(()=>{S.pend=null;push(true)},60);return}
 S.lastSend=t;const snap=SY.snapshot();const msg={type:'state',seq:++S.seq,pub:snap.pub,priv:snap.priv};
 if(S.ws&&S.ws.readyState===1)try{S.ws.send(JSON.stringify(msg))}catch(e){}
 if(S.bc&&S.bcSeen)try{S.bc.postMessage(msg)}catch(e){}}
SY.push=push;
setInterval(()=>{if(listeners())push(true)},250);
if(window.V7)V7.on('change',()=>push());

/* ---------- WebSocket to the hub ---------- */
async function probe(){if(!/^https?:$/.test(location.protocol)){S.server=false;return false}
 try{const r=await fetch('api/config',{cache:'no-store'});const j=await r.json();S.server=!!j.ws}catch(e){S.server=false}
 if(S.server){try{const r=await fetch('api/lan',{cache:'no-store'});const j=await r.json();S.ips=j.ips||[];S.port=String(j.port||location.port||'')}catch(e){}}
 return S.server}
SY.start=async()=>{C.on=true;saveC();S.err='';clearTimeout(S.timer);if(!(await probe())){setStatus('noserver');return}connect()};
SY.stop=()=>{C.on=false;saveC();clearTimeout(S.timer);if(S.ws){try{S.ws.send(JSON.stringify({type:'bye'}))}catch(e){}const w=S.ws;S.ws=null;try{w.close(1000)}catch(e){}}S.peers=[];setStatus('off')};
SY.newPin=()=>{C.pin=genPin();saveC();if(C.on){if(S.ws){try{S.ws.send(JSON.stringify({type:'bye'}))}catch(e){}try{S.ws.onclose=null;S.ws.close(1000)}catch(e){}S.ws=null}connect()}render()};
SY.newRoom=()=>{C.room=genRoom();C.pin=genPin();saveC();if(C.on){if(S.ws){try{S.ws.send(JSON.stringify({type:'bye'}))}catch(e){}try{S.ws.onclose=null;S.ws.close(1000)}catch(e){}S.ws=null}connect()}render()};
SY.kick=cid=>{if(S.ws&&S.ws.readyState===1)S.ws.send(JSON.stringify({type:'kick',cid}))};
function setStatus(s,err){S.status=s;if(err!=null)S.err=err;render();badge()}
function connect(){clearTimeout(S.timer);const proto=location.protocol==='https:'?'wss:':'ws:';
 const url=`${proto}//${location.host}/ws?role=HOST&room=${encodeURIComponent(C.room)}&pin=${C.pin}&token=${encodeURIComponent(C.token)}`;
 let ws;try{ws=new WebSocket(url)}catch(e){setStatus('error',e.message);return}S.ws=ws;setStatus('connecting');
 ws.onopen=()=>{S.retry=0;setStatus('on','');push(true)};
 ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch(err){return}
  if(m.type==='peers'){const before=S.peers.length;S.peers=m.list||[];if(S.peers.length>before){D.toast(`📱 ${roleFa(S.peers[S.peers.length-1].role)} وصل شد`);try{V7.log(`PHONE JOIN ${S.peers[S.peers.length-1].role}`)}catch(err){}}render();badge();push(true);return}
  if(m.type==='cmd'){const res=SY.exec(m.action,m.payload,{id:m.id,role:m.role,via:'ws'});try{ws.send(JSON.stringify({type:'ack',cid:m.cid,id:m.id,ok:res.ok!==false,err:res.err||'',dup:!!res.dup,msg:res.msg||''}))}catch(err){}return}
  if(m.type==='ping'){try{ws.send(JSON.stringify({type:'pong',cid:m.cid,t:m.t}))}catch(err){}return}};
 ws.onclose=e=>{if(S.ws!==ws)return;S.ws=null;S.peers=[];
  if(e.code===4009){C.on=false;saveC();setStatus('error','یک کامپیوتر دیگر میزبان همین اتاق است. «اتاق جدید» بزنید.');return}
  if(e.code===4000){setStatus('error','اتاق یا PIN نامعتبر');return}
  if(!C.on){setStatus('off');return}
  const wait=Math.min(5000,500*Math.pow(2,S.retry++));setStatus('retry');S.timer=setTimeout(connect,wait)}}

/* ---------- same device: BroadcastChannel (no server) ---------- */
try{S.bc=new BroadcastChannel('dadashmode-sync');S.bc.onmessage=e=>{const m=e.data||{};
 if(m.type==='hello'&&m.room===C.room&&m.pin===C.pin){S.bcSeen=Date.now();push(true);return}
 if(m.type==='cmd'&&m.room===C.room&&m.pin===C.pin){S.bcSeen=Date.now();const res=SY.exec(m.action,m.payload,{id:m.id,role:m.role,via:'bc'});S.bc.postMessage({type:'ack',cid:m.cid,id:m.id,ok:res.ok!==false,err:res.err||'',dup:!!res.dup});return}
 if(m.type==='ping'&&m.room===C.room){S.bcSeen=Date.now();S.bc.postMessage({type:'pong',cid:m.cid,t:m.t})}}}catch(e){}
setInterval(()=>{if(S.bcSeen&&Date.now()-S.bcSeen>15000)S.bcSeen=0},5000);

/* ---------- pairing drawer ---------- */
const base=()=>{const ip=C.ip||S.ips[0]||location.hostname;const port=S.port||location.port;const local=/^(localhost|127\.|::1)/.test(ip);
 return {url:`${location.protocol}//${ip}${port&&!(location.protocol==='http:'&&port==='80')&&!(location.protocol==='https:'&&port==='443')?':'+port:''}${location.pathname.replace(/[^/]*$/,'')}remote.html`,local}};
SY.link=role=>{const b=base();return `${b.url}?room=${C.room}&pin=${C.pin}${role?'&role='+role:''}`};
const dr=D.drawer('sync','📱 حالت گوشی (کنترل هم‌زمان)',[['pair','جفت‌سازی'],['peers','دستگاه‌ها و الگ'],['help','راهنما']]);
const PILL={off:['خاموش',''],connecting:['در حال اتصال…',''],on:['روشن · آماده اتصال گوشی','grn'],retry:['قطع شد · تلاش دوباره…',''],noserver:['سرور محلی پیدا نشد',''],error:['خطا','']};
function render(){if(!dr.isOpen())return;const t=dr.tab||'pair';let h='';const pl=PILL[S.status]||['?',''];
 if(t==='pair'){const b=base();
  h=`<div class="dm5-card"><div class="dm5-row"><span class="dm5-pill ${pl[1]}">${pl[0]}</span>${S.err?`<span class="dm5-muted" style="color:#ffb347">${esc(S.err)}</span>`:''}
   ${C.on?`<button class="dm5-btn" data-s="stop">خاموش کردن حالت گوشی</button>`:`<button class="dm5-btn pri big" data-s="start">روشن کردن حالت گوشی</button>`}</div>
   <div class="dm5-row" style="gap:18px;margin-top:8px"><div>اتاق <b style="font-size:26px;letter-spacing:3px" dir="ltr">${esc(C.room)}</b></div><div>PIN <b style="font-size:26px;letter-spacing:3px" dir="ltr">${esc(C.pin)}</b></div>
   <button class="dm5-btn" data-s="pin">PIN جدید</button><button class="dm5-btn" data-s="room">اتاق جدید</button></div>
   ${S.status==='noserver'?`<div class="dm5-muted" style="color:#ffb347;margin-top:6px">حالت گوشی به سرور محلی نیاز دارد: اپ را با <b dir="ltr">node server.js</b> (یا «شروع ویندوز») باز کنید، نه با دوبار کلیک روی فایل یا از GitHub Pages. روی همین دستگاه، remote.html در تب دیگر بدون سرور هم کار می‌کند.</div>`:''}
   ${b.local?`<div class="dm5-muted" style="color:#ffb347;margin-top:6px">آدرس QR «localhost» است و گوشی آن را پیدا نمی‌کند. IP کامپیوتر در همان Wi-Fi را انتخاب یا وارد کنید.</div>`:''}
   <div class="dm5-row" style="margin-top:6px">آدرس کامپیوتر: <select class="dm5-in" data-ip>${[...new Set([...(S.ips||[]),C.ip||''].filter(Boolean))].map(ip=>`<option ${ip===(C.ip||S.ips[0])?'selected':''}>${esc(ip)}</option>`).join('')}<option value="">— خودکار —</option></select>
   <input class="dm5-in" data-ipin placeholder="یا دستی: 192.168.1.5" style="width:160px" dir="ltr"><button class="dm5-btn" data-s="ip">ثبت</button></div></div>
  <div class="dm5-card"><h4>QR را با دوربین گوشی اسکن کنید</h4><div class="v8s-qrs">${ROLES.map(([r,n])=>`<figure class="v8s-qr"><canvas data-qr="${r}"></canvas><figcaption><b>${n}</b><button class="dm5-btn" data-copy="${r}">کپی لینک</button></figcaption></figure>`).join('')}
   <figure class="v8s-qr"><canvas data-qr=""></canvas><figcaption><b>انتخاب نقش روی گوشی</b><button class="dm5-btn" data-copy="">کپی لینک</button></figcaption></figure></div>
   <p class="dm5-muted" dir="ltr" style="word-break:break-all;margin:6px 0 0">${esc(SY.link(''))}</p>
   <p class="dm5-muted">گوشی و کامپیوتر باید در یک Wi-Fi (یا هات‌اسپات لپ‌تاپ) باشند. اینترنت لازم نیست. کلید F2 همین صفحه را باز می‌کند.</p></div>`}
 if(t==='peers'){h=`<div class="dm5-card"><h4>گوشی‌های وصل (${fa(S.peers.length)})</h4>${S.peers.length?S.peers.map(p=>`<div class="dm5-row"><b>${esc(roleFa(p.role))}</b><span class="dm5-muted" dir="ltr">${esc(p.ip||'')}</span><span class="dm5-muted">${esc((p.ua||'').replace(/Mozilla\/5\.0 \(|\).*$/g,'').slice(0,40))}</span><span class="dm5-muted">از ${esc(new Date(p.since).toLocaleTimeString('fa-IR'))}</span><button class="dm5-btn" data-kick="${esc(p.cid)}">بیرون کردن</button></div>`).join(''):'<p class="dm5-muted">هنوز گوشی‌ای وصل نشده.</p>'}
  ${S.bcSeen?'<p class="dm5-muted">● یک کنترل روی همین دستگاه (تب دیگر) وصل است.</p>':''}</div>
  <div class="dm5-card"><h4>آخرین فرمان‌های گوشی</h4>${S.log.length?S.log.map(l=>`<div class="dm5-row"><span class="dm5-muted">${esc(new Date(l.t).toLocaleTimeString('fa-IR'))}</span><b>${esc(roleFa(l.role))}</b><span dir="ltr">${esc(l.action)}</span>${l.ok?'<span class="dm5-pill grn">✔</span>':`<span class="dm5-pill">✕ ${esc(l.err)}</span>`}</div>`).join(''):'<p class="dm5-muted">فرمانی نیامده. همهٔ فرمان‌ها با نقش و شناسه در ژورنال هم ثبت می‌شوند.</p>'}</div>`}
 if(t==='help'){h=`<div class="dm5-card"><h4>نقش‌ها (کتاب §۹٫۲)</h4><p><b>کارگردان:</b> بانک‌ها، مرحله، تایمر، دکمه‌های همان مرحله، UNDO، مکث، زیرنویس، جملهٔ بعدی جمنای با TTS، مرحلهٔ بعد، بخش‌های قسمت و بازی‌های جدید.</p>
  <p><b>بازیکن E / M:</b> فقط دکمه‌های خودش: «تمام» راند ۴، انتخاب مخفی کارت، شرط ریسک، «تمام» بازی‌های جدید. انتخابش روی صفحهٔ کامپیوتر و گوشی کارگردان دیده نمی‌شود.</p>
  <p><b>داور سوم:</b> دهان‌پر / خالی ✔، غلط، معتبر، چالش چسب، گل، ریسک، مرگ ناگهانی، ثبت امتیاز بازی‌های جدید.</p><p><b>مانیتور:</b> تمام‌صفحه بدون دکمه.</p>
  <h4>اطمینان</h4><p class="dm5-muted">هر فرمان یک شناسهٔ یکتا دارد و تکرارش نادیده گرفته می‌شود؛ قطع Wi-Fi و اتصال دوباره هیچ فرمانی را دوبار اجرا نمی‌کند. زمان هر رویداد را کامپیوتر ثبت می‌کند. نقش هر گوشی را سرور تعیین می‌کند، نه خود گوشی. SYNC بالای ۱۵۰ms روی گوشی زرد می‌شود.</p></div>`}
 dr.body.innerHTML=h;
 if(t==='pair'&&window.QR)dr.body.querySelectorAll('canvas[data-qr]').forEach(cv=>{try{QR.draw(cv,SY.link(cv.dataset.qr),{scale:4,margin:3})}catch(e){}})}
dr.render=render;
dr.body.addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;const a=b.dataset.s;
 if(a==='start')await SY.start();else if(a==='stop')SY.stop();else if(a==='pin')SY.newPin();else if(a==='room')SY.newRoom();
 else if(a==='ip'){const v=(dr.body.querySelector('[data-ipin]').value||'').trim();if(v&&!/^[\w.\-:]+$/.test(v)){D.toast('آدرس نامعتبر');return}C.ip=v;saveC();render()}
 else if(b.dataset.kick)SY.kick(b.dataset.kick);
 else if(b.dataset.copy!=null){const l=SY.link(b.dataset.copy);try{await navigator.clipboard.writeText(l);D.toast('لینک کپی شد')}catch(err){prompt('لینک:',l)}}});
dr.body.addEventListener('change',e=>{if(e.target.matches('[data-ip]')){C.ip=e.target.value;saveC();render()}});
function badge(){const b=document.getElementById('dm5b-sync');if(!b)return;const n=S.peers.length+(S.bcSeen?1:0);b.textContent=n?`📱 ${fa(n)}`:'📱';b.classList.toggle('v8s-live',S.status==='on')}
D.dockButton('sync','📱',()=>dr.toggle(),'v8s-dock');
if(window.V7)V7.on('ui',k=>{if(k==='pair'||k==='sync'){dr.tab='pair';dr.open();if(!C.on)SY.start()}});
setInterval(()=>{if(dr.isOpen()&&dr.tab==='peers'&&!dr.body.contains(document.activeElement))render()},2000);
/* resume after reload: if phone mode was on, turn it back on (same room/PIN → phones reconnect by themselves) */
if(C.on)setTimeout(()=>SY.start(),600);
})();
