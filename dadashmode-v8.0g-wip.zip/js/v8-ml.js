/* DADASHMODE V8 · v8-ml.js · reusable seasons
   1) Claude prompt builder: the prompt is generated from the app's LIVE registries (segment types, games, emotions,
      V7 states, rule config, list shapes), so it always matches what this build can actually run.
   2) .ml episode file (JSON; also accepts a ```json code fence, // comments and trailing commas).
   3) Validation report (errors block the build, warnings don't).
   4) Build a brand-new episode from the .ml (current episode is never touched), and export any episode back to .ml.
   5) Per-episode overlay: state order (flow), state names and Gemini intro lines come from the active episode.
   Pure core works in Node (globalThis.V8ML) for tools/v8-ml-selftest.mjs; UI only binds when the DOM exists. */
(function(root){'use strict';
const FORMAT='dadashmode-ml/1';
const G=n=>{try{return root[n]!==undefined?root[n]:(0,eval)(n)}catch(e){return undefined}};
const R=()=>root.V7R;
/* modules = groups of V7 states that always run together */
const MODULES={READY:['READY'],R1:['R1'],R2:['R2'],R3_SANDWICH:['R3_SANDWICH'],TWIST_BANKOPEN:['TWIST_BANKOPEN'],R4_GLUE:['R4_GLUE'],REVEAL:['REVEAL'],SHOP:['SHOP','SHOP_REVEAL'],RISK:['RISK'],VAULT:['VAULT_ARMED','RUN1','RUN2'],CASE:['CASE','CASE_L1','CASE_L2','CASE_L3'],END:['END']};
const MODULE_OF=s=>Object.keys(MODULES).find(m=>MODULES[m].includes(s))||(s==='GLUE_CHALLENGE'?'R4_GLUE':null);
const BOOK_FLOW=['READY','R1','R2','R3_SANDWICH','TWIST_BANKOPEN','R4_GLUE','REVEAL','SHOP','RISK','VAULT','CASE','END'];

function registry(){const r=R()||{};const EMO=G('EMO')||{};return {
 types:G('TYPES')||{},games:G('GAMES')||{},emotions:Object.fromEntries(Object.entries(EMO).map(([k,v])=>[k,v.fa||k])),
 voices:(G('GEMINI_VOICES')||[]).map(v=>v[0]),states:r.STATES||[],stateFa:r.STATE_FA||{},cfg:r.CFG||{},
 cards:(r.CARDS||[]).map(c=>({id:c.id,fa:c.fa,price:c.price,color:c.color})),modules:MODULES}}

/* ---------------- parse ---------------- */
function stripJsonish(t){let out='',i=0,q=null;while(i<t.length){const c=t[i],n=t[i+1];
  if(q){out+=c;if(c==='\\'){out+=n||'';i+=2;continue}if(c===q)q=null;i++;continue}
  if(c==='"'){q=c;out+=c;i++;continue}
  if(c==='/'&&n==='/'){while(i<t.length&&t[i]!=='\n')i++;continue}
  if(c==='/'&&n==='*'){i+=2;while(i<t.length&&!(t[i]==='*'&&t[i+1]==='/'))i++;i+=2;continue}
  out+=c;i++}
 return out.replace(/,(\s*[}\]])/g,'$1')}
function parse(text){text=String(text||'').replace(/^\uFEFF/,'');const errors=[];
 const fences=[...text.matchAll(/```(?:json|ml|jsonc)?\s*\n([\s\S]*?)```/gi)].map(m=>m[1]);
 let body=fences.length?fences.sort((a,b)=>b.length-a.length)[0]:text;
 if(!fences.length){const a=body.indexOf('{'),b=body.lastIndexOf('}');if(a>0||b<body.length-1){if(a>=0&&b>a)body=body.slice(a,b+1)}}
 if(/^\s*[a-zA-Z_]+\s*:\s/m.test(body)&&!/^\s*[{[]/.test(body)){errors.push('فایل به شکل YAML است. این نسخه فقط JSON می‌پذیرد؛ از Claude بخواهید خروجی را JSON بدهد.');return {data:null,errors}}
 try{return {data:JSON.parse(stripJsonish(body)),errors}}catch(e){errors.push('JSON خوانده نشد: '+e.message);return {data:null,errors}}}

/* ---------------- normalise lists to the engine's internal shapes ---------------- */
const arr=x=>Array.isArray(x)?x:[];
const str=x=>x==null?'':String(x).trim();
const faDigit=x=>+String(x).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
function normTargets(l){return arr(l).map((t,i)=>{if(typeof t==='string')t={name:t};const name=str(t.name);const acc=arr(t.accept).map(str).filter(Boolean);if(name&&!acc.includes(name))acc.unshift(name);return {n:+t.n||i+1,name,accept:acc,note:str(t.note),callback:!!t.callback,v7:!!t.callback}})}
function normRiddles(l){return arr(l).map((r,i)=>{const a=faDigit(r.answer);return {id:str(r.id)||`${a}-ml${String(i+1).padStart(2,'0')}`,answer:a,normal:str(r.normal||r.text),spicy:str(r.spicy)||str(r.normal||r.text),hint:str(r.hint),used:false,src:'.ml'}})}
function normEnvelopes(l){return arr(l).map((e,i)=>({n:+e.n||i+1,title:str(e.title),desc:str(e.desc),scoreEffect:!!e.scoreEffect}))}
function normBites(l){return arr(l).map((b,i)=>({n:+b.n||i+1,emoji:str(b.emoji)||'🎁',title:str(b.title),react:str(b.react),mild:!!b.mild}))}

/* ---------------- validate ---------------- */
function validate(d){const E=[],W=[],reg=registry();
 if(!d||typeof d!=='object'||Array.isArray(d))return {errors:['فایل باید یک شیء JSON باشد'],warnings:[],stats:{}};
 if(d.format&&d.format!==FORMAT)W.push(`format برابر «${d.format}» است؛ انتظار «${FORMAT}» بود`);
 if(!str(d.name))E.push('name (نام قسمت) خالی است');
 if(d.startBank!==undefined&&!Number.isFinite(+d.startBank))E.push('startBank عدد نیست');
 const pl=arr(d.players);if(pl.length!==2)E.push(`players باید دقیقاً ۲ نفر باشد (الان ${pl.length})`);
 pl.forEach((p,i)=>{if(!str(p.name))E.push(`players[${i}] نام ندارد`);if(p.color&&!/^#[0-9a-f]{6}$/i.test(p.color))W.push(`رنگ بازیکن ${i+1} باید به شکل #rrggbb باشد`)});
 const sp=arr(d.speakers);const spIds=new Set(sp.map(s=>str(s.id)).filter(Boolean));if(!sp.length)W.push('speakers خالی است؛ «host» ساخته می‌شود');if(!spIds.size)spIds.add('host');
 sp.forEach(s=>{if(s.voice&&reg.voices.length&&(s.provider||'gemini')==='gemini'&&!reg.voices.includes(s.voice))W.push(`صدای «${s.voice}» در فهرست صداهای جمنای نیست`)});
 const segs=arr(d.segments);if(!segs.length)E.push('segments (بخش‌ها) خالی است');
 const emoFa=Object.fromEntries(Object.entries(reg.emotions).map(([k,v])=>[v,k]));let lines=0;const usedStates=[];
 segs.forEach((s,i)=>{const at=`بخش ${i+1}${s.title?' «'+s.title+'»':''}`;
  if(!reg.types[s.type])E.push(`${at}: type نامعتبر «${s.type}» (مجاز: ${Object.keys(reg.types).join(', ')})`);
  if(s.game&&!reg.games[s.game])W.push(`${at}: game «${s.game}» ناشناخته است؛ «generic» (تایمر + امتیاز دستی) در نظر گرفته می‌شود`);
  if(s.v7){if(!reg.states.includes(s.v7))E.push(`${at}: v7 نامعتبر «${s.v7}»`);else usedStates.push(s.v7)}
  if(s.type==='play'&&!s.v7&&!s.engine)W.push(`${at}: بازی بدون engine و بدون v7 → فقط امتیاز دستی`);
  if(s.type==='play'&&!s.v7&&(!s.game||s.game==='generic')&&!Number.isFinite(+s.duration))W.push(`${at}: بازی جدید بدون duration`);
  if(s.type==='play'&&!s.v7&&(!s.game||s.game==='generic')&&!arr(s.rules).length)W.push(`${at}: بازی جدید قانون (rules) ندارد`);
  if(s.engine!==undefined){if(s.v7)W.push(`${at}: engine روی بخشی که v7 دارد نادیده گرفته می‌شود`);else if(s.type!=='play')E.push(`${at}: engine فقط روی بخش type=play`);else{const G8=root.V8G;if(G8){const c=G8.check(s.engine);c.errors.forEach(x=>E.push(`${at}: ${x}`));c.warnings.forEach(x=>W.push(`${at}: ${x}`))}}}
  arr(s.lines).forEach((l,j)=>{lines++;if(!str(l.text))W.push(`${at}، دیالوگ ${j+1}: متن خالی`);
   if(l.speaker&&!spIds.has(l.speaker))E.push(`${at}، دیالوگ ${j+1}: گوینده «${l.speaker}» در speakers نیست`);
   if(l.emotion&&!reg.emotions[l.emotion]&&!emoFa[l.emotion])W.push(`${at}، دیالوگ ${j+1}: لحن «${l.emotion}» ناشناخته؛ «warm» می‌شود`)})});
 const flow=arr(d.flow);flow.forEach(m=>{if(!MODULES[m])E.push(`flow: ماژول ناشناخته «${m}» (مجاز: ${Object.keys(MODULES).join(', ')})`)});
 if(flow.includes('CASE')&&!flow.includes('VAULT'))W.push('flow: کیف طلایی بدون فینال گاوصندوق برنده ندارد');
 const L=d.lists||{};
 if(L.targets){const t=normTargets(L.targets);if(t.some(x=>!x.name))E.push('lists.targets: هدف بدون name');if(t.length<4)W.push(`lists.targets فقط ${t.length} هدف دارد`)}
 if(L.riddles){const r=normRiddles(L.riddles);r.forEach((x,i)=>{if(!(x.answer>=0&&x.answer<=9))E.push(`lists.riddles[${i}]: answer باید رقم ۰ تا ۹ باشد`);if(!x.normal)E.push(`lists.riddles[${i}]: متن normal خالی است`)});
  const miss=[0,1,2,3,4,5,6,7,8,9].filter(n=>!r.some(x=>x.answer===n));if(miss.length)W.push(`lists.riddles برای رقم‌های ${miss.join('، ')} معما ندارد (قالب ریاضی پشتیبان استفاده می‌شود)`)}
 if(L.envelopes&&normEnvelopes(L.envelopes).some(e=>!e.title))E.push('lists.envelopes: پاکت بدون title');
 if(L.bites){const b=normBites(L.bites);if(b.some(x=>!x.title))E.push('lists.bites: جعبه بدون title');if(b.length&&b.length<3)W.push('lists.bites کمتر از ۳ جعبه دارد')}
 const cfgKeys=(o,base,path)=>{for(const k in o){if(!(k in base)){W.push(`rules.${path}${k} در موتور وجود ندارد و نادیده گرفته می‌شود`);continue}if(o[k]&&typeof o[k]==='object'&&!Array.isArray(o[k])&&typeof base[k]==='object')cfgKeys(o[k],base[k],path+k+'.')}};
 if(d.rules)cfgKeys(d.rules,reg.cfg,'');
 if(d.intros)for(const k in d.intros)if(!reg.states.includes(k))W.push(`intros: حالت «${k}» وجود ندارد`);
 if(d.stateNames)for(const k in d.stateNames)if(!reg.states.includes(k))W.push(`stateNames: حالت «${k}» وجود ندارد`);
 arr(d._report).forEach(x=>W.push('گزارش Claude: '+str(typeof x==='string'?x:JSON.stringify(x))));
 const newGames=segs.filter(s=>s.type==='play'&&!s.v7).length;const autoGames=segs.filter(s=>s.type==='play'&&!s.v7&&s.engine).length;
 return {errors:E,warnings:W,stats:{segments:segs.length,lines,newGames,autoGames,v7Modules:[...new Set(usedStates.map(MODULE_OF))].filter(Boolean).length,targets:arr(L.targets).length,riddles:arr(L.riddles).length,envelopes:arr(L.envelopes).length,bites:arr(L.bites).length}}}

/* ---------------- .ml → episode ---------------- */
function flowFromSegments(segs){const f=[];segs.forEach(s=>{const m=s.v7&&MODULE_OF(s.v7);if(m&&!f.includes(m))f.push(m)});if(f.length&&f[0]!=='READY')f.unshift('READY');if(f.length&&!f.includes('END'))f.push('END');return f}
function toEpisode(d){const reg=registry();const emoFa=Object.fromEntries(Object.entries(reg.emotions).map(([k,v])=>[v,k]));
 const speakers=(arr(d.speakers).length?arr(d.speakers):[{id:'host',name:'مجری',provider:'gemini',voice:'Leda'}]).map(s=>({id:str(s.id)||'host',name:str(s.name)||'مجری',provider:s.provider||'gemini',voice:s.voice||'Leda'}));
 const players=arr(d.players).slice(0,2).map((p,i)=>({name:str(p.name),color:p.color||(i?'#00c98d':'#ff2738'),symbol:p.symbol||(i?'●':'▲'),key:p.key||(i?'l':'a')}));
 const segments=arr(d.segments).map(s=>{const o={type:s.type,game:reg.games[s.game]?s.game:'generic',title:str(s.title),subtitle:str(s.subtitle),rules:arr(s.rules).map(str).filter(Boolean),duration:Number.isFinite(+s.duration)?+s.duration:30,reward:Number.isFinite(+s.reward)?+s.reward:10,notes:str(s.notes),issue:'',status:'ok',winner:'',
  lines:arr(s.lines).map(l=>({speaker:str(l.speaker)||speakers[0].id,emotion:reg.emotions[l.emotion]?l.emotion:(emoFa[l.emotion]||'warm'),text:str(l.text),direction:str(l.direction)}))};
  if(s.v7)o.v7=s.v7;if(s.engine&&!s.v7&&s.type==='play'){o.engine=JSON.parse(JSON.stringify(s.engine));o.game='generic'}if(s.scoring)o.notes=(o.notes?o.notes+' · ':'')+'امتیاز: '+str(s.scoring);return o});
 const L=d.lists||{};const bank={};
 if(arr(L.targets).length)bank.targets=normTargets(L.targets);if(arr(L.riddles).length)bank.riddles=normRiddles(L.riddles);
 if(arr(L.envelopes).length)bank.envelopes=normEnvelopes(L.envelopes);if(arr(L.bites).length)bank.bites=normBites(L.bites);if(L.punish)bank.punish=L.punish;
 bank.source='.ml · '+(str(d.season)||'')+' · '+new Date().toISOString().slice(0,10);
 const flow=arr(d.flow).length?arr(d.flow):flowFromSegments(arr(d.segments));
 const p={format:'dadashmode-episode/3',v7book:'ml',name:str(d.name),unit:str(d.unit)||'ثانیه',startBank:Number.isFinite(+d.startBank)?+d.startBank:(reg.cfg.start||45),speakers,segments,v7bank:bank,
  v8ml:{format:FORMAT,season:str(d.season),episode:d.episode||null,flow,intros:d.intros||{},stateNames:d.stateNames||{},importedAt:Date.now()}};
 if(players.length===2)p.players=players;if(d.theme)p.theme=d.theme;if(d.brief)p.brief=d.brief;if(d.rules&&Object.keys(d.rules).length)p.v7cfg=d.rules;
 if(Number.isFinite(+d.startBank))p.v7cfg=Object.assign({},p.v7cfg||{},{start:+d.startBank});
 return p}

/* ---------------- episode → .ml (so every finished season becomes the template of the next) ---------------- */
function fromEpisode(p){const b=p.v7bank||{};const strip=o=>JSON.parse(JSON.stringify(o));
 const ml={format:FORMAT,season:(p.v8ml&&p.v8ml.season)||'',episode:(p.v8ml&&p.v8ml.episode)||null,name:p.name,unit:p.unit,startBank:p.startBank,
  players:(p.players||[]).map(x=>({name:x.name,color:x.color,symbol:x.symbol,key:x.key})),speakers:(p.speakers||[]).map(s=>({id:s.id,name:s.name,provider:s.provider,voice:s.voice})),
  theme:p.theme,brief:p.brief,flow:(p.v8ml&&p.v8ml.flow&&p.v8ml.flow.length)?p.v8ml.flow:flowFromSegments(p.segments||[]),rules:p.v7cfg||{},
  intros:(p.v8ml&&p.v8ml.intros)||{},stateNames:(p.v8ml&&p.v8ml.stateNames)||{},
  lists:{targets:(b.targets||(R()&&R().TARGETS)||[]).map(t=>({name:t.name,accept:t.accept,note:t.note||'',callback:!!t.callback})),
   riddles:(b.riddles||(R()&&R().RIDDLES)||[]).map(r=>({answer:r.answer,normal:r.normal,spicy:r.spicy,hint:r.hint})),
   envelopes:(b.envelopes||(R()&&R().ENVELOPES)||[]).map(e=>({title:e.title,desc:e.desc,scoreEffect:!!e.scoreEffect})),
   bites:(b.bites||(R()&&R().BITES)||[]).map(x=>({emoji:x.emoji,title:x.title,react:x.react,mild:!!x.mild})),punish:b.punish||undefined},
  segments:(p.segments||[]).map(s=>{const o={type:s.type,game:s.game,title:s.title,subtitle:s.subtitle,rules:s.rules||[],duration:s.duration,reward:s.reward,notes:s.notes||''};if(s.v7)o.v7=s.v7;if(s.engine)o.engine=s.engine;o.lines=(s.lines||[]).map(l=>({speaker:l.speaker,emotion:l.emotion,text:l.text,direction:l.direction||''}));return o})};
 return strip(ml)}

/* ---------------- Claude prompt ---------------- */
function buildPrompt(opt={}){const reg=registry();const ex=opt.example||null;
 const J=o=>JSON.stringify(o,null,1);
 const exampleSegs=ex?ex.segments.filter(s=>['title','intro','rules','play'].includes(s.type)).slice(0,4):[];
 return `# نقش
تو دستیار پیش‌تولید برنامهٔ مسابقهٔ یوتیوبی «داداش‌مود» هستی. فایل PDF «کتاب کارگردانی» فصل/قسمت جدید پیوست شده${opt.withDialogues?' (به‌همراه PDF دیالوگ‌ها)':''}. کارت این است که کل محتوای اجرایی کتاب را استخراج کنی و در قالب دقیق فایل «.ml» تحویل بدهی تا اپ کنترل داداش‌مود همهٔ بخش‌ها، قوانین، دیالوگ‌ها، زیرنویس‌ها و فهرست‌ها را از روی آن بسازد.

# قوانین استخراج (مهم)
1. متن دیالوگ‌ها، قانون‌ها و فهرست‌ها را **عیناً** از کتاب بردار؛ چیزی از خودت نساز. اگر چیزی در کتاب نیست، فیلد را خالی بگذار و در «_report» بنویس چه چیزی کم است.
2. اگر کتاب نسخه‌های متناقض دارد، جدیدترین بخش/نسخه برنده است؛ تناقض را در «_report» گزارش کن.
3. ترتیب «segments» = ترتیب اجرای واقعی سر صحنه (همان جدول زمان‌بندی کتاب).
4. هر خط دیالوگ یک آیتم جدا در «lines» است، با گوینده و لحن. توضیح صحنه/دوربین در «direction» یا «notes»، نه در «text».
5. اعداد را به رقم لاتین بنویس (45 نه ۴۵) در فیلدهای عددی؛ داخل متن فارسی هر شکلی مجاز است.
6. خروجی فقط و فقط **یک بلوک \`\`\`json** باشد، بدون هیچ توضیح قبل یا بعد. JSON معتبر (بدون کامنت).

# بازی‌ها: موتور آماده یا بازی جدید
اپ برای این بازی‌ها موتور قانون خودکار دارد (امتیاز، تایمر، کارت‌ها، گاوصندوق). اگر بازی کتاب جدید همان منطق را دارد، بخش را با فیلد «v7» به حالت مربوط وصل کن:
${reg.states.map(s=>`- ${s}: ${reg.stateFa[s]||''}`).join('\n')}
ماژول‌ها (واحد «flow»؛ حالت‌های داخل یک ماژول همیشه با هم اجرا می‌شوند):
${Object.entries(MODULES).map(([k,v])=>`- ${k} = ${v.join(' → ')}`).join('\n')}
اگر بازی کتاب **جدید** است و با هیچ‌کدام جور نیست: بخش type="play" و game="generic" بساز، **بدون v7**، با duration (ثانیه)، reward، rules (قانون‌ها خط به خط)، «scoring» (شرح امتیازدهی عیناً از کتاب) و **«engine»** تا اپ امتیاز را خودکار حساب کند. در «_report» بنویس کدام بازی‌ها جدیدند و engine هرکدام را چطور از کتاب برداشتی.

## engine (موتور بازی جدید) · یکی از ۴ حالت
- "first": اولین نفری که معتبر تمام کند reward می‌گیرد. tie.band = اختلاف زمانی که «هم‌زمان» حساب می‌شود (ثانیه) و tie.award = امتیاز هر نفر در تساوی. fallback = امتیاز وقتی هیچ‌کس تمام نکرد (پیشرفت بیشتر برنده؛ برابر = هیچ).
- "points": رویدادهای قابل‌شمارش (گل، پرتاب موفق، ...). events=[{"id","label","value","max"}] (max = سقف تعداد برای هر نفر). award="winner" (جمع بیشتر reward می‌گیرد) یا "sum" (هر نفر جمع خودش را می‌گیرد).
- "metric": هر نفر یک عدد (زمان، فاصله، تعداد). metric={"label":"متر","better":"higher|lower","scale":"fixed|diff","factor":1,"floor":3,"cap":20}. scale=diff یعنی امتیاز برنده = اختلاف × factor، بین floor و cap (مثل دوئل ساندویچ).
- "judge": داور برنده/تساوی/بدون برنده را انتخاب می‌کند؛ برنده reward.
مشترک: limit (سقف زمان، ثانیه)، reward، penalties=[{"id","label","value"}] (خطاها، مستقیم از بانک کم می‌شوند)، loser (امتیاز/جریمهٔ بازنده)، maxAward.
مثال: {"mode":"metric","limit":45,"reward":10,"metric":{"label":"سانتی‌متر","better":"lower","scale":"diff","factor":0.5,"floor":3,"cap":15},"tie":{"band":1,"award":5},"penalties":[{"id":"foul","label":"پا از خط رد شد","value":3}]}
«flow» ترتیب ماژول‌های خودکار را تعیین می‌کند (ماژولی که در کتاب نیست را حذف کن). اگر حذفش کنی، اپ آن را از ترتیب v7 بخش‌ها می‌سازد.

# مقادیر مجاز
- segments[].type: ${Object.entries(reg.types).map(([k,v])=>`${k} (${v})`).join('، ')}
- segments[].game: ${Object.entries(reg.games).map(([k,v])=>`${k} (${v})`).join('، ')}
- lines[].emotion: ${Object.entries(reg.emotions).map(([k,v])=>`${k} (${v})`).join('، ')}
- speakers[].voice (جمنای): ${reg.voices.join('، ')}
- lines[].speaker باید یکی از speakers[].id باشد.

# قوانین عددی قابل تغییر («rules»؛ فقط کلیدهایی که کتاب جدید عوض کرده را بنویس)
مقادیر فعلی موتور:
${J(reg.cfg)}
کارت‌های فروشگاه (ثابت در این نسخه): ${reg.cards.map(c=>`${c.id}=${c.fa} (${c.price}، ${c.color})`).join('، ')}

# ساختار کامل فایل .ml
{
 "format": "${FORMAT}",
 "season": "نام/شمارهٔ فصل",
 "episode": 1,
 "name": "نام قسمت",
 "unit": "ثانیه",
 "startBank": 45,
 "players": [{"name":"...","color":"#ff2738","symbol":"▲","key":"a"},{"name":"...","color":"#00c98d","symbol":"●","key":"l"}],
 "speakers": [{"id":"host","name":"...","provider":"gemini","voice":"Leda"}],
 "theme": {"name":"...","bg1":"#12060a","bg2":"#4f0d1c","accent":"#ff3b3b","accent2":"#ffd23f","ink":"#fff7ec","shade":"#7a0f1f","font":"Lalezar"},
 "brief": {"summary":"...","tone":"...","characters":["..."],"beats":["..."],"directorNotes":["..."]},
 "flow": ["READY","R1","...","END"],
 "rules": {"r1":{"limit":30}},
 "stateNames": {"R1":"اسم نمایشی این مرحله در این فصل"},
 "intros": {"R1":["گوینده","جملهٔ اعلام ورود به مرحله"]},
 "lists": {
  "targets":   [{"name":"دوچرخه","accept":["دوچرخه","بایسیکل"],"note":"","callback":false}],
  "riddles":   [{"answer":0,"normal":"متن معما","spicy":"نسخهٔ سخت با همان جواب","hint":"جملهٔ ذره‌بین"}],
  "envelopes": [{"title":"حق وتو","desc":"...","scoreEffect":false}],
  "bites":     [{"emoji":"🍋","title":"...","react":"...","mild":false}],
  "punish":    {"mode":"bite","eatSeconds":10,"picks":2}
 },
 "segments": [
  {"type":"intro","game":"cup","v7":"R1","title":"...","subtitle":"...","rules":["..."],"duration":30,"reward":10,"notes":"یادداشت کارگردان/دوربین",
   "lines":[{"speaker":"host","emotion":"serious","text":"...","direction":""}]},
  {"type":"play","game":"generic","title":"بازی جدید","rules":["..."],"duration":60,"reward":10,"scoring":"...",
   "engine":{"mode":"points","limit":60,"reward":10,"events":[{"id":"hit","label":"گل","value":1,"max":5}],"award":"winner","tie":{"award":5}},"lines":[]}
 ],
 "_report": ["چیزهایی که در کتاب پیدا نشد یا مبهم بود"]
}
${exampleSegs.length?`
# نمونهٔ واقعی از فصل قبل (فقط برای دیدن سبک؛ کپی نکن)
${J(exampleSegs)}
`:''}
# چک نهایی قبل از تحویل
- دقیقاً ۲ بازیکن؛ هر بخش type معتبر؛ هر v7 از فهرست بالا؛ هر riddle.answer رقم ۰ تا ۹.
- برای هر رقم ۰ تا ۹ حداقل یک معما اگر کتاب دارد.
- همهٔ دیالوگ‌های کتاب آمده‌اند (تعداد تقریبی را در _report بنویس).
- فقط یک بلوک \`\`\`json. نام پیشنهادی فایل: season-episode.ml
${opt.extra?'\n# توضیح اضافهٔ کارگردان\n'+opt.extra+'\n':''}`}

/* ---------------- per-episode overlay (flow, names, intros) ---------------- */
let DEF=null;
function overlay(p){const r=R(),V7=root.V7;if(!r||!V7||!V7.NEXT||!V7.INTRO)return false;
 if(!DEF)DEF={NEXT:Object.assign({},V7.NEXT),INTRO:JSON.parse(JSON.stringify(V7.INTRO)),FA:Object.assign({},r.STATE_FA)};
 const reset=(o,src)=>{for(const k in o)delete o[k];Object.assign(o,JSON.parse(JSON.stringify(src)))};
 reset(V7.NEXT,DEF.NEXT);reset(V7.INTRO,DEF.INTRO);reset(r.STATE_FA,DEF.FA);
 const m=p&&p.v8ml;if(!m)return false;
 const flow=arr(m.flow).filter(x=>MODULES[x]);if(flow.length){const st=flow.flatMap(x=>MODULES[x]);if(st[st.length-1]!=='END')st.push('END');for(let i=0;i<st.length-1;i++)V7.NEXT[st[i]]=st[i+1];V7.NEXT.END='END';V7.NEXT.GLUE_CHALLENGE='R4_GLUE'}
 for(const k in (m.intros||{})){const v=m.intros[k];if(Array.isArray(v)&&v.length>=2)V7.INTRO[k]=[str(v[0]),str(v[1])];else if(typeof v==='string')V7.INTRO[k]=['جمنای',v]}
 for(const k in (m.stateNames||{}))if(r.STATE_FA[k]!==undefined)r.STATE_FA[k]=str(m.stateNames[k]);
 return true}

const V8ML={FORMAT,MODULES,BOOK_FLOW,registry,parse,validate,toEpisode,fromEpisode,buildPrompt,overlay,flowFromSegments};
root.V8ML=V8ML;if(typeof module!=='undefined'&&module.exports)module.exports=V8ML;

/* ================= UI (browser only) ================= */
if(typeof document==='undefined')return;
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const faN=n=>String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
const curP=()=>{try{return (0,eval)('P')}catch(e){return null}};
const dl=(text,name,type)=>{const b=new Blob([text],{type:type||'text/plain;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500)};
const toast=(m,ms)=>{try{(0,eval)('toast')(m,ms)}catch(e){console.log(m)}};
const safe=s=>String(s||'episode').replace(/[\\/:*?"<>|\s]+/g,'-').slice(0,60);
let pending=null;

function mount(){if($('#view-ml'))return;
 const tabs=$('#tabs');if(tabs&&!tabs.querySelector('[data-view="ml"]')){const b=document.createElement('button');b.setAttribute('role','tab');b.dataset.view='ml';b.setAttribute('aria-selected','false');b.textContent='فصل جدید (.ml)';const ref=tabs.querySelector('[data-view="projects"]');tabs.insertBefore(b,ref?ref.nextSibling:null)}
 const sec=document.createElement('section');sec.id='view-ml';sec.className='hidden';sec.innerHTML=`
 <div class="page">
  <div class="page-head"><div><h1>فصل و قسمت جدید با فایل .ml</h1>
   <p>اپ یک‌بارمصرف نیست. ۱) پرامپت را بسازید و همراه PDF کتاب کارگردانی جدید به Claude بدهید. ۲) جوابش را به شکل فایل .ml ذخیره و اینجا وارد کنید. ۳) بعد از قبول‌شدن بررسی، قسمت جدید با همهٔ بخش‌ها، قوانین، دیالوگ‌ها، زیرنویس‌ها و فهرست‌ها ساخته می‌شود. قسمت فعلی دست‌نخورده می‌ماند.</p></div></div>
  <div class="split">
   <div class="block"><h2>۱ · پرامپت Claude</h2>
    <label class="row muted"><input type="checkbox" id="mlWithDlg" checked> PDF دیالوگ‌ها هم پیوست می‌شود</label>
    <label class="row muted"><input type="checkbox" id="mlWithEx" checked> نمونه از قسمت فعلی داخل پرامپت بیاید</label>
    <label class="f">توضیح اضافهٔ شما برای Claude (اختیاری)<textarea id="mlExtra" rows="3" placeholder="مثلاً: این فصل بازی جدید «پرتاب کفش» دارد"></textarea></label>
    <div class="row" style="margin-top:10px"><button class="btn pri" id="mlMake">ساخت پرامپت</button><button class="btn" id="mlCopy">کپی</button><button class="btn" id="mlDlPrompt">دانلود .txt</button></div>
    <textarea id="mlPrompt" rows="14" readonly style="margin-top:10px;width:100%;direction:rtl"></textarea>
    <h2 style="margin-top:18px">خروجی .ml از قسمت فعلی</h2>
    <p class="muted" style="margin-top:0">قسمت باز را به فایل .ml تبدیل می‌کند؛ هم نسخهٔ پشتیبان است، هم نمونهٔ کامل برای فصل بعد.</p>
    <button class="btn" id="mlExport">دانلود .ml قسمت فعلی</button>
   </div>
   <div class="block"><h2>۲ · ورود فایل .ml و بررسی</h2>
    <div class="row"><label class="btn pri">انتخاب فایل .ml<input type="file" id="mlFile" accept=".ml,.json,.md,.txt,text/*" hidden></label></div>
    <label class="f" style="margin-top:10px">یا جواب Claude را مستقیم اینجا بچسبانید<textarea id="mlPaste" rows="6" style="direction:ltr"></textarea></label>
    <button class="btn" id="mlCheck">بررسی متن چسبانده‌شده</button>
    <div id="mlReport" style="margin-top:12px"></div>
    <div class="row" style="margin-top:12px"><button class="btn pri" id="mlBuild" disabled>۳ · ساخت قسمت جدید</button></div>
   </div>
  </div>
 </div>`;
 const main=document.querySelector('main');(main||document.body).appendChild(sec);
 $('#mlMake').onclick=()=>{const p=curP();let ex=null;if($('#mlWithEx').checked&&p&&p.segments)ex=fromEpisode(p);$('#mlPrompt').value=buildPrompt({withDialogues:$('#mlWithDlg').checked,example:ex,extra:$('#mlExtra').value.trim()});toast('پرامپت ساخته شد')};
 $('#mlCopy').onclick=async()=>{if(!$('#mlPrompt').value)$('#mlMake').click();try{await navigator.clipboard.writeText($('#mlPrompt').value);toast('کپی شد')}catch(e){$('#mlPrompt').select();document.execCommand('copy');toast('کپی شد')}};
 $('#mlDlPrompt').onclick=()=>{if(!$('#mlPrompt').value)$('#mlMake').click();dl($('#mlPrompt').value,'dadashmode-claude-prompt.txt')};
 $('#mlExport').onclick=()=>{const p=curP();if(!p){toast('قسمتی باز نیست');return}dl(JSON.stringify(fromEpisode(p),null,1),safe(p.name)+'.ml','application/json')};
 $('#mlFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;check(await f.text(),f.name);e.target.value=''};
 $('#mlCheck').onclick=()=>check($('#mlPaste').value,'متن چسبانده‌شده');
 $('#mlBuild').onclick=async()=>{if(!pending)return;try{const ep=toEpisode(pending);const imp=(0,eval)('importEpisodeJSON');await imp(ep);setTimeout(()=>overlay(curP()),50);toast('قسمت جدید ساخته شد: '+ep.name,4000)}catch(err){console.error(err);toast('ساخت قسمت ناموفق بود: '+err.message,5000)}};
}
function check(text,label){pending=null;$('#mlBuild').disabled=true;const out=$('#mlReport');const pr=parse(text);
 if(!pr.data){out.innerHTML=`<p style="color:#ef4444"><b>${esc(label)}:</b> ${pr.errors.map(esc).join('<br>')}</p>`;return}
 const v=validate(pr.data);const s=v.stats;
 out.innerHTML=`<p><b>${esc(pr.data.name||label)}</b> · ${faN(s.segments)} بخش · ${faN(s.lines)} دیالوگ · ${faN(s.v7Modules)} ماژول خودکار · ${faN(s.newGames)} بازی جدید (${faN(s.autoGames)} با امتیاز خودکار) · فهرست‌ها: ${faN(s.targets)} هدف، ${faN(s.riddles)} معما، ${faN(s.envelopes)} پاکت، ${faN(s.bites)} جعبه</p>`+
  (v.errors.length?`<p style="color:#ef4444;margin:6px 0"><b>${faN(v.errors.length)} خطا (باید رفع شود):</b></p><ul>${v.errors.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:'<p style="color:#22c55e"><b>بدون خطا ✓</b></p>')+
  (v.warnings.length?`<details ${v.errors.length?'':'open'}><summary class="muted">${faN(v.warnings.length)} هشدار</summary><ul>${v.warnings.map(x=>`<li class="muted">${esc(x)}</li>`).join('')}</ul></details>`:'');
 if(!v.errors.length){pending=pr.data;$('#mlBuild').disabled=false}}
function boot(){try{mount()}catch(e){console.warn('[V8ML mount]',e)}
 const tabs=$('#tabs');if(tabs)tabs.addEventListener('click',e=>{const b=e.target.closest('button[data-view]');if(!b)return;const v=b.dataset.view==='ml';const sec=$('#view-ml');if(sec&&v){document.querySelectorAll('#tabs button').forEach(x=>x.setAttribute('aria-selected',x===b));document.querySelectorAll('main>section').forEach(s=>s.classList.toggle('hidden',s.id!=='view-ml'))}});
 let last=null;setInterval(()=>{const p=curP();const id=p&&(p.id+':'+(p.v8ml?p.v8ml.importedAt:'-'));if(id!==last){last=id;try{overlay(p)}catch(e){console.warn('[V8ML overlay]',e)}}},800)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})(typeof globalThis!=='undefined'?globalThis:window);
